package hilos;

import mundo.*;

import java.io.IOException;

import interfaz.*;

public class HiloBala extends Thread {
	private InterfazPrincipal principal;
	private Bala bala;

	public HiloBala(InterfazPrincipal ventana, Bala bal) {
		principal = ventana;
		bala = bal;
	}

	public void run() {

		while (principal.obtenerTablero().getTanqueJugador().getVida() == 5) {
			bala.disparar();
			if (bala.getDireccion().equals("AVANZAR")) {
				derecha();
				derechaTanque();
				jugadorDerecha();
			} else if (bala.getDireccion().equals("RETROCEDER")) {
				izquierda();
				izquierdaTanque();
				jugadorIzquierda();
			} else if (bala.getDireccion().equals("ARRIBA")) {
				arriba();
				arribaTanque();
				jugadorArriba();
			} else if (bala.getDireccion().equals("ABAJO")) {
				abajo();
				abajoTanque();
				jugadorAbajo();
			}
			try {
				sleep(10);
			} catch (Exception e) {
			}
			principal.refrescar();
		}
	}

	public void derecha() {
		boolean termino = false;
		if (bala.getDireccion().equals("AVANZAR") && bala != null) {
			for (int i = 0; i < principal.obtenerTablero().getMuros().size() && !termino; i++) {
				if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Ladrillo ) {
					Muro_Ladrillo la = (Muro_Ladrillo) principal.obtenerTablero().getMuros().get(i);
					if (bala.getPosx() + 2 >= la.getPosx() && bala.getPosx() <= la.getPosx() + la.getAncho()) {
						if (bala.getPosy() + 2 >= la.getPosy() && bala.getPosy() <= la.getPosy() + la.getAlto()) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.cambiarImagen(dano, bala.getDireccion());
							if (la.getVida() == 0 && la.destruido()) {
								int num = principal.obtenerTablero().BuscarMuroBinario(i);
								principal.obtenerTablero().getMuros().remove(num);
								termino = true;
							}
						}
					}
				} else if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible la = (Muro_Indestructible) principal.obtenerTablero().getMuros().get(i);
					if (bala.getPosx() >= la.getPosX() && bala.getPosx() <= la.getPosX() + la.getAncho()) {
						if (bala.getPosy() >= la.getPosY() && bala.getPosy() <= la.getPosY() + la.getAlto()) {
							bala.setEstado(false);
						}
					}
				}

			}
		}
	}

	public void derechaTanque() {
		boolean termino = false;
		int conto = 0;
		if (bala.getDireccion().equals("AVANZAR") && bala != null && !bala.isTanque()) {
			for (int i = 0; i < principal.obtenerTablero().getTanquesEnemigos().size() && !termino; i++) {
				if (principal.obtenerTablero().getTanquesEnemigos().get(i) != null) {
					if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E1) {
						Tanque_E1 la = (Tanque_E1) principal.obtenerTablero().getTanquesEnemigos().get(i);
						if (bala.getPosx() + 2 >= la.getPosX() && bala.getPosx() <= la.getPosX() + 30) {
							if (bala.getPosy() + 2 >= la.getPosY() && bala.getPosy() <= la.getPosY() + 30) {
								int dano = bala.getDano();
								bala.setEstado(false);
								bala.setPosx(1000);
								bala.setPosy(1000);
								la.destruirTanque(dano);
								if (la.getVida() == 0 && la.isEstado() == true) {
									int puntaje = ((Tanque_E1) la).getRecompensa();
									principal.obtenerTablero().getTanquesEnemigos().remove(i);
									principal.obtenerTablero().getJuga().acumularPuntaje(puntaje);
									principal.eliminaronTanque();
									principal.agregarTanques();
								}
								principal.refrescar();
							}
						}
					} else if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E2) {
						Tanque_E2 la = (Tanque_E2) principal.obtenerTablero().getTanquesEnemigos().get(i);
						if (bala.getPosx() + 2 >= la.getPosX() && bala.getPosx() <= la.getPosX() + 30) {
							if (bala.getPosy() + 2 >= la.getPosY() && bala.getPosy() <= la.getPosY() + 30) {
								int dano = bala.getDano();
								bala.setEstado(false);
								bala.setPosx(1000);
								bala.setPosy(1000);
								la.destruirTanque(dano);
								if (la.getVida() == 0 && la.isDestruido()) {
									int puntaje = ((Tanque_E2) la).getRecompensa();
									principal.obtenerTablero().getTanquesEnemigos().remove(i);
									principal.obtenerTablero().getJuga().acumularPuntaje(puntaje);
									principal.eliminaronTanque();
									principal.agregarTanques();
								}
								principal.refrescar();
							}
						}
					}
				}
				conto++;
				if (conto == 3) {
					termino = true;
				}
			}
		}
	}

	public void izquierda() {
		boolean termino = false;
		if (bala.getDireccion().equals("RETROCEDER")) {
			for (int i = 0; i < principal.obtenerTablero().getMuros().size() && !termino; i++) {
				if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo la = (Muro_Ladrillo) principal.obtenerTablero().getMuros().get(i);
					if (bala.getPosx() >= la.getPosx() && bala.getPosx() <= la.getPosx() + la.getAncho()) {
						if (bala.getPosy() >= la.getPosy() && bala.getPosy() <= la.getPosy() + la.getAlto()) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.cambiarImagen(dano, bala.getDireccion());
							if (la.getVida() == 0 && la.destruido()) {
								int num = principal.obtenerTablero().BuscarMuroBinario(i);
								principal.obtenerTablero().getMuros().remove(num);
								termino = true;
							}
							principal.refrescar();
						}
					}
				} else if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible la = (Muro_Indestructible) principal.obtenerTablero().getMuros().get(i);
					if (bala.getPosx() >= la.getPosX() && bala.getPosx() <= la.getPosX() + la.getAncho()) {
						if (bala.getPosy() >= la.getPosY() && bala.getPosy() <= la.getPosY() + la.getAlto()) {
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							principal.refrescar();
						}
					}
				}
			}
		}
	}

	public void izquierdaTanque() {
		boolean termino = false;
		int cuenta = 0;
		if (bala.getDireccion().equals("RETROCEDER") && bala != null && !bala.isTanque()) {
			for (int i = 0; i < principal.obtenerTablero().getTanquesEnemigos().size() && !termino; i++) {
				if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E1) {
					Tanque_E1 la = (Tanque_E1) principal.obtenerTablero().getTanquesEnemigos().get(i);
					if (bala.getPosx() >= la.getPosX() && bala.getPosx() <= la.getPosX() + 30) {
						if (bala.getPosy() >= la.getPosY() && bala.getPosy() <= la.getPosY() + 30) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.destruirTanque(dano);
							if (la.getVida() == 0 && la.isEstado()) {
								int puntaje = ((Tanque_E1) la).getRecompensa();
								principal.obtenerTablero().getTanquesEnemigos().remove(i);
								principal.obtenerTablero().getJuga().acumularPuntaje(puntaje);
								principal.eliminaronTanque();
								principal.agregarTanques();
							}
							principal.refrescar();
						}
					}
				} else if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E2) {
					Tanque_E2 la = (Tanque_E2) principal.obtenerTablero().getTanquesEnemigos().get(i);
					if (bala.getPosx() + 2 >= la.getPosX() && bala.getPosx() <= la.getPosX() + 30) {
						if (bala.getPosy() + 2 >= la.getPosY() && bala.getPosy() <= la.getPosY() + 30) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.destruirTanque(dano);
							if (la.getVida() == 0 && la.isDestruido()) {
								int puntaje = ((Tanque_E2) la).getRecompensa();
								principal.obtenerTablero().getTanquesEnemigos().remove(i);
								principal.obtenerTablero().getJuga().acumularPuntaje(puntaje);
								principal.eliminaronTanque();
								principal.agregarTanques();
							}
							principal.refrescar();
						}
					}
				}
				cuenta++;
				if (cuenta == 3) {
					termino = true;
				}
			}
		}
	}

	public void arriba() {
		boolean termino = false;
		if (bala.getDireccion().equals("ARRIBA")) {
			for (int i = 0; i < principal.obtenerTablero().getMuros().size() && !termino; i++) {
				if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo la = (Muro_Ladrillo) principal.obtenerTablero().getMuros().get(i);
					if (bala.getPosx() >= la.getPosx() && bala.getPosx() <= la.getPosx() + la.getAncho()) {
						if (bala.getPosy() >= la.getPosy() && bala.getPosy() <= la.getPosy() + la.getAlto()) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.cambiarImagen(dano, bala.getDireccion());
							if (la.getVida() == 0 && la.destruido()) {
								int num = principal.obtenerTablero().BuscarMuroBinario(i);
								principal.obtenerTablero().getMuros().remove(num);
								termino = true;
							}
							principal.refrescar();
						}
					}
				} else if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible la = (Muro_Indestructible) principal.obtenerTablero().getMuros().get(i);
					if (bala.getPosx() >= la.getPosX() && bala.getPosx() <= la.getPosX() + la.getAncho()) {
						if (bala.getPosy() >= la.getPosY() && bala.getPosy() <= la.getPosY() + la.getAlto()) {
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							principal.refrescar();
						}
					}
				}
			}
		}
	}

	public void arribaTanque() {
		boolean termino = false;
		int conto = 0;
		if (bala.getDireccion().equals("ARRIBA") && bala != null && !bala.isTanque()) {
			for (int i = 0; i < principal.obtenerTablero().getTanquesEnemigos().size() && !termino; i++) {
				if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E1) {
					Tanque_E1 la = (Tanque_E1) principal.obtenerTablero().getTanquesEnemigos().get(i);
					if (bala.getPosx() >= la.getPosX() && bala.getPosx() <= la.getPosX() + 30) {
						if (bala.getPosy() >= la.getPosY() && bala.getPosy() <= la.getPosY() + 30) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.destruirTanque(dano);
							if (la.getVida() == 0 && la.isEstado()) {
								int puntaje = ((Tanque_E1) la).getRecompensa();
								principal.obtenerTablero().getTanquesEnemigos().remove(i);
								principal.obtenerTablero().getJuga().acumularPuntaje(puntaje);
								principal.eliminaronTanque();
								principal.agregarTanques();
							}
							principal.refrescar();
						}
					}
				} else if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E2) {
					Tanque_E2 la = (Tanque_E2) principal.obtenerTablero().getTanquesEnemigos().get(i);
					if (bala.getPosx() + 2 >= la.getPosX() && bala.getPosx() <= la.getPosX() + 30) {
						if (bala.getPosy() + 2 >= la.getPosY() && bala.getPosy() <= la.getPosY() + 30) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.destruirTanque(dano);
							if (la.getVida() == 0 && la.isDestruido()) {
								int puntaje = ((Tanque_E2) la).getRecompensa();
								principal.obtenerTablero().getTanquesEnemigos().remove(i);
								principal.obtenerTablero().getJuga().acumularPuntaje(puntaje);
								principal.eliminaronTanque();
								principal.agregarTanques();
							}
							principal.refrescar();
						}
					}
				}
				conto++;
				if (conto == 3) {
					termino = true;
				}
			}
		}
	}

	public void abajo() {
		boolean termino = false;
		if (bala.getDireccion().equals("ABAJO")) {
			for (int i = 0; i < principal.obtenerTablero().getMuros().size() && !termino; i++) {
				if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo la = (Muro_Ladrillo) principal.obtenerTablero().getMuros().get(i);
					if (bala.getPosx() >= la.getPosx() && bala.getPosx() <= la.getPosx() + la.getAncho()) {
						if (bala.getPosy() >= la.getPosy() && bala.getPosy() <= la.getPosy() + la.getAlto()) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.cambiarImagen(dano, bala.getDireccion());
							if (la.getVida() == 0 && la.destruido()) {
								int num = principal.obtenerTablero().BuscarMuroBinario(i);
								principal.obtenerTablero().getMuros().remove(num);
								termino = true;
							}
							principal.refrescar();

						}
					}
				} else if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible la = (Muro_Indestructible) principal.obtenerTablero().getMuros().get(i);
					if (bala.getPosx() >= la.getPosX() && bala.getPosx() <= la.getPosX() + la.getAncho()) {
						if (bala.getPosy() >= la.getPosY() && bala.getPosy() <= la.getPosY() + la.getAlto()) {
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							principal.refrescar();
						}
					}
				}
			}
		}
	}

	public void abajoTanque() {
		boolean termino = false;
		int conto = 0;
		if (bala.getDireccion().equals("ABAJO") && bala != null && !bala.isTanque()) {
			for (int i = 0; i < principal.obtenerTablero().getTanquesEnemigos().size() && !termino; i++) {
				if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E1) {
					Tanque_E1 la = (Tanque_E1) principal.obtenerTablero().getTanquesEnemigos().get(i);
					if (bala.getPosx() >= la.getPosX() && bala.getPosx() <= la.getPosX() + 30) {
						if (bala.getPosy() >= la.getPosY() && bala.getPosy() <= la.getPosY() + 30) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.destruirTanque(dano);
							if (la.getVida() == 0 && la.isEstado()) {
								int puntaje = ((Tanque_E1) la).getRecompensa();
								principal.obtenerTablero().getTanquesEnemigos().remove(i);
								principal.obtenerTablero().getJuga().acumularPuntaje(puntaje);
								principal.eliminaronTanque();
								principal.agregarTanques();
							}
							principal.refrescar();
						}
					}
				} else if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E2) {
					Tanque_E2 la = (Tanque_E2) principal.obtenerTablero().getTanquesEnemigos().get(i);
					if (bala.getPosx() + 2 >= la.getPosX() && bala.getPosx() <= la.getPosX() + 30) {
						if (bala.getPosy() + 2 >= la.getPosY() && bala.getPosy() <= la.getPosY() + 30) {
							int dano = bala.getDano();
							bala.setEstado(false);
							bala.setPosx(1000);
							bala.setPosy(1000);
							la.destruirTanque(dano);
							if (la.getVida() == 0 && la.isDestruido()) {
								int puntaje = ((Tanque_E2) la).getRecompensa();
								principal.obtenerTablero().getTanquesEnemigos().remove(i);
								principal.obtenerTablero().getJuga().acumularPuntaje(puntaje);
								principal.eliminaronTanque();
								principal.agregarTanques();
							}
							principal.refrescar();
						}
					}
				}
				conto++;
				if (conto == 3) {
					termino = true;
				}
			}
		}
	}

	public void jugadorDerecha() {
		if (bala.getDireccion().equals("DERECHA") && bala != null && bala.isTanque()) {
			TanqueJugador jugador = principal.obtenerTablero().getTanqueJugador();
			if (bala.getPosx() + 2 >= jugador.getPosX() && bala.getPosx() <= jugador.getPosX() + 30) {
				if (bala.getPosy() + 2 >= jugador.getPosY() && bala.getPosy() <= jugador.getPosY() + 30) {
					jugador.quitarVidaj(bala.getDanoj());
					try {
						principal.perdio();
					} catch (IOException e) {
						System.out.println("No guardo");
					}
				}
			}
		}
	}

	public void jugadorIzquierda() {
		if (bala.getDireccion().equals("RETROCEDER") && bala != null && bala.isTanque()) {
			TanqueJugador jugador = principal.obtenerTablero().getTanqueJugador();
			if (bala.getPosx() + 2 >= jugador.getPosX() && bala.getPosx() <= jugador.getPosX() + 30) {
				if (bala.getPosy() + 2 >= jugador.getPosY() && bala.getPosy() <= jugador.getPosY() + 30) {
					jugador.quitarVidaj(bala.getDanoj());
					try {
						principal.perdio();
					} catch (IOException e) {
						System.out.println("No guardo");
					}
				}
			}
		}
	}

	public void jugadorArriba() {
		if (bala.getDireccion().equals("ARRIBA") && bala != null && bala.isTanque()) {
			TanqueJugador jugador = principal.obtenerTablero().getTanqueJugador();
			if (bala.getPosx() + 2 >= jugador.getPosX() && bala.getPosx() <= jugador.getPosX() + 30) {
				if (bala.getPosy() + 2 >= jugador.getPosY() && bala.getPosy() <= jugador.getPosY() + 30) {
					jugador.quitarVidaj(bala.getDanoj());
					try {
						principal.perdio();
					} catch (IOException e) {
						System.out.println("No guardo");
					}
				}
			}
		}
	}

	public void jugadorAbajo() {
		if (bala.getDireccion().equals("ABAJO") && bala != null && bala.isTanque()) {
			TanqueJugador jugador = principal.obtenerTablero().getTanqueJugador();
			if (bala.getPosx() + 2 >= jugador.getPosX() && bala.getPosx() <= jugador.getPosX() + 30) {
				if (bala.getPosy() + 2 >= jugador.getPosY() && bala.getPosy() <= jugador.getPosY() + 30) {
					jugador.quitarVidaj(bala.getDanoj());
					try {
						principal.perdio();
					} catch (IOException e) {
						System.out.println("No guardo");
					}
				}
			}
		}
	}
}
