package mundo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Properties;

public class Tablero {
	public static final String RUTA_GUARDAR = "./data/JuegoGuardado/";
	private ArrayList<Muro> muros;
	private ArrayList<Tanque> tanquesEnemigos;
	private Jugador juga;
	private TanqueJugador tanqueJugador;
	private Aguila_Defender winCondition;
	private ArrayList<Bala> balas;
	private Bala bala;
	private int vidaMuro;
	private Puntaje primero;
	private Tanque[] tanques;

	public Tablero() {
		juga = new Jugador();
		tanquesEnemigos = new ArrayList<Tanque>();
		balas = new ArrayList<Bala>();
		bala = new Bala();
		muros = new ArrayList<Muro>();
		vidaMuro = Muro.VIDA_NORMAL;
		try {
			Puntaje probar1 = new Puntaje("JUAN CARLOS", 20000, "00:25");
			Puntaje probar2 = new Puntaje("PRUEBA 2", 8888, "01:45");
			Puntaje probar3 = new Puntaje("Daniela", 50000, "05:35");
			agregarJugador(probar1);
			agregarJugador(probar2);
			agregarJugador(probar3);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public Bala agregarBala(int posX, int posY, String direccion) {
		Bala nueva = new Bala(posX, posY, direccion);
		balas.add(nueva);
		return nueva;
	}

	public void cargarEscenario(File archivoTablero) throws Exception {
		BufferedReader lector = new BufferedReader(new FileReader(archivoTablero));
		String linea = lector.readLine();
		muros = new ArrayList<Muro>();
		while (linea != null && !linea.isEmpty()) {
			if (linea.charAt(0) == '#') {
				String[] coordenada = linea.split(":");
				int cantidadMuros = Integer.parseInt(coordenada[1]);
				for (int i = 0; i < cantidadMuros; i++) {
					linea = lector.readLine();
					String posiciones = linea;
					String[] pos = posiciones.split(":");
					String nuevo = pos[1];
					String[] posFinales = nuevo.split(",");
					int posX = Integer.parseInt(posFinales[0]);
					int posY = Integer.parseInt(posFinales[1]);
					try {
						if (linea.charAt(0) == '-') {
							Muro_Indestructible actu = new Muro_Indestructible(5000, Muro.IMAGEN, false, posX, posY, 30,
									30);
							muros.add(actu);
						} else {
							Muro_Ladrillo actual = new Muro_Ladrillo(vidaMuro, Muro.IMAGEN, false, posX, posY, 30, 30);
							muros.add(actual);
						}
					} catch (Exception e) {
						throw new Exception("No se puede agregar los muros");
					}
					if (i == cantidadMuros - 1) {
						linea = lector.readLine();
					}
				}
			} else if (linea.charAt(0) == 'A') {
				String[] aguila = linea.split(":");
				String agui = aguila[1];
				String[] a = agui.split(",");
				winCondition = new Aguila_Defender(Integer.parseInt(a[0]), Integer.parseInt(a[1]));
				linea = lector.readLine();
			} else if (linea.charAt(0) == 'P') {
				String[] jugador = linea.split(":");
				String coordenadas = jugador[1];
				String[] co = coordenadas.split(",");
				tanqueJugador = new TanqueJugador(Integer.parseInt(co[0]), Integer.parseInt(co[1]), this, 30, 200);
				linea = lector.readLine();
			} else if (linea.charAt(0) == 'N') {
				String[] coordenada = linea.split(":");
				int cantidadTanquesNormales = Integer.parseInt(coordenada[1]);
				for (int i = 0; i < cantidadTanquesNormales; i++) {
					linea = lector.readLine();
					String posiciones = linea;
					String[] pos = posiciones.split(":");
					String nuevo = pos[1];
					String[] posFinales = nuevo.split(",");
					int posX = Integer.parseInt(posFinales[0]);
					int posY = Integer.parseInt(posFinales[1]);
					try {
						if (linea.charAt(0) == 'N') {
							Tanque_E1 actual = new Tanque_E1(5, posX, posY, Tanque.TANQUE_ENEMIGO,
									Tanque.MOVIMIENTO_TANQUE_NORMAL, false, 100);
							tanquesEnemigos.add(actual);
						} else if (linea.charAt(0) == 'E') {
							Tanque_E2 actual = new Tanque_E2(15, Tanque.TANQUE_ENEMIGO, Tanque.MOVIMIENTO_TANQUE_MEDIO,
									posX, posY, false, 200);
							tanquesEnemigos.add(actual);
						}
					} catch (Exception e) {
						throw new Exception("No se pudo agregar los tanques enemigos normales");
					}
					if (i == cantidadTanquesNormales - 1) {
						linea = lector.readLine();
					}
				}
			}
		}
		lector.close();
		tanques = new Tanque[tanquesEnemigos.size()];
		for (int i = 0; i < tanques.length; i++) {
			tanques[i] = tanquesEnemigos.get(i);
		}
	}

	public void guardar(File f) throws IOException {
		PrintWriter p = new PrintWriter(f);
		p.write("#MurosLadrillos:" + muros.size() + "\n");

		for (int i = 0; i < muros.size(); i++) {
			if (muros.get(i) instanceof Muro_Ladrillo) {
				Muro_Ladrillo m = (Muro_Ladrillo) muros.get(i);
				p.write("Muro" + i + ":" + m.getPosx() + "," + m.getPosy() + "\n");
			} else if (muros.get(i) instanceof Muro_Indestructible) {
				Muro_Indestructible in = (Muro_Indestructible) muros.get(i);
				p.write("-Muro" + i + ":" + in.getPosX() + "," + in.getPosY() + "\n");
			}
		}
		p.write("APosicionAguila:" + winCondition.getPosX() + "," + winCondition.getPosY() + "\n");
		p.write("PosicionJugador:" + tanqueJugador.getPosX() + "," + tanqueJugador.getPosY() + "\n");
		p.write("NTanquesNormalesEnemigos:" + tanquesEnemigos.size() + "\n");
		for (int i = 0; i < tanquesEnemigos.size(); i++) {
			if (tanquesEnemigos.get(i) instanceof Tanque_E1) {
				Tanque_E1 actu = (Tanque_E1) tanquesEnemigos.get(i);
				p.write("NTanqueEnemigo:" + i + ":" + actu.getPosX() + "," + actu.getPosY() + "\n");
			} else if (tanquesEnemigos.get(i) instanceof Tanque_E2) {
				Tanque_E2 actu = (Tanque_E2) tanquesEnemigos.get(i);
				p.write("ETanqueEnemigo:" + i + ":" + actu.getPosX() + "," + actu.getPosY() + "\n");
			}
		}
		p.close();
	}

	public void guardarJugadoresSerializado(File f) throws IOException {
		ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(f));
		Puntaje actual = primero;
		try {
			salida.writeObject(actual);
		} catch (Exception e) {
			System.out.println("Salio mal");
		}
		salida.close();
	}
	public void guardarRanqueo() throws IOException{
		ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("./data/Jugadores/Ranked.txt"));
		Puntaje actual=primero;
		Puntaje[] vector=mostrarRanked(actual);
		try {
			salida.writeObject(vector);
		} catch (Exception e) {
			System.out.println("No sirvio");
		}
		salida.close();
	}
	public Puntaje[] mostrarRanked(Puntaje inicial) {
		int tamano=0;
		Puntaje actual=inicial;
		Puntaje arre=actual;
		while(actual!=null) {
			tamano++;
			actual=actual.getSiguiente();
		}
		Puntaje[] arreglo=new Puntaje[tamano];
		for (int i = 0; i < arreglo.length; i++) {
			if(i==0) {
				arreglo[i]=arre;
				arre=arre.getSiguiente();
			}else {
				if(arre!=null) {
				arreglo[i]=arre;
				arre=arre.getSiguiente();
			}else {
				Puntaje vacio=new Puntaje("Null",0,"00:00");
				arreglo[i]=vacio;
			}
			}
		}
		//Burbuja
		int n=arreglo.length;
		for (int i = 0; i <= n-2; i++) {
			for (int j = n-1; j>i; j--) {
				if(arreglo[j-1].getPuntajeJugador()<arreglo[j].getPuntajeJugador()) {
					permuta(arreglo, j-1, j);
				}
			}
		}
		return arreglo;
	}
	public void permuta(Puntaje[]a, int i, int j) {
		Puntaje t;
		t=a[i];
		a[i]=a[j];
		a[j]=t;
	}
	public Puntaje buscarMejorPuntajeRecursivo(Puntaje actual, Puntaje sig,Puntaje retornar) {
		Puntaje primero=actual;
		Puntaje siguiente=sig;
		Puntaje aux=retornar;
		if(sig==null) {
			return aux;
		}else {
			if(siguiente!=null && primero.getPuntajeJugador()<siguiente.getPuntajeJugador()) {
				aux=siguiente;
				primero=siguiente;
				siguiente=siguiente.getSiguiente();
				return buscarMejorPuntajeRecursivo(primero, siguiente,aux);
			}else {
				return aux;
			}
		}
	}
	public Puntaje buscarJugadorRecursivo(String nombre, Puntaje parametro) {
		Puntaje actual=parametro;
		if(actual==null) {
			return actual;
		}else {
			if(actual.getNombreJugador().equals(nombre)) {
				return actual;
			}else {
				return buscarJugadorRecursivo(nombre,actual.getSiguiente());
			}
		}
	}
	

	public int BuscarMuroBinario(int i) {
		int primero, centro, ultimo;
		centro = 0;
		primero = 0;
		ultimo = muros.size();
		boolean encontro = false;
		while (primero <= ultimo && !encontro) {
			centro = (primero + ultimo) / 2;
			if (centro == i) {
				encontro = true;
				return centro;
			} else if (i > centro) {
				primero = centro + 1;
			} else {
				ultimo = centro - 1;
			}
		}
		return -1;
	}
	public void agregarJugador(Puntaje p,Puntaje primero)throws YaExisteJugadorException{
		Puntaje actual=primero;
		if(actual==null) {
			actual=p;
		}else {
			if(actual!=null) {
				agregarJugador(p,actual.getSiguiente());
			}
		}
		
	}

	public void agregarJugador(Puntaje p) throws YaExisteJugadorException {
		boolean ex = false;
		Puntaje sig = primero;

		while (sig != null && !ex) {
			if (p.comparar(sig)) {
				ex = true;
			}
			sig = sig.getSiguiente();
		}

		if (!ex) {

			if (primero == null) {
				primero = p;
			} else {

				Puntaje antesDe = primero;
				while (antesDe.getNombreJugador().compareTo(p.getNombreJugador()) > 0
						&& antesDe.getSiguiente() != null) {
					antesDe = antesDe.getSiguiente();
				}
				p.setAnterior(antesDe);
				p.setSiguiente(antesDe.getSiguiente());

				if (antesDe.getSiguiente() == null) {
					antesDe.setSiguiente(p);
				} else {
					antesDe.getSiguiente().setAnterior(p);
					antesDe.setSiguiente(p);
				}

			}

		} else {
			throw new YaExisteJugadorException("Ya existe este jugador", p.getNombreJugador());
		}

	}

	public boolean eliminarJugador(String codigo) {
		boolean elimino = false;
		Puntaje anterior = null;
		try {
			Puntaje eliminiar = primero;
			Puntaje siguiente = primero.getSiguiente();
			while (eliminiar != null && !eliminiar.getNombreJugador().equalsIgnoreCase(codigo)) {
				anterior = eliminiar;
				eliminiar = eliminiar.getSiguiente();
				siguiente = eliminiar.getSiguiente();
			}
			if (eliminiar == primero) {
				if (eliminiar.getSiguiente() != null) {
					primero = siguiente;
					primero.setAnterior(null);
					elimino = true;
				} else {
					primero = null;
					elimino = true;
				}
			} else if (anterior != null && eliminiar != null) {
				anterior.setSiguiente(siguiente);
				elimino = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return elimino;
	}

	public Puntaje getPrimero() {
		return primero;
	}

	public void setPrimero(Puntaje primero) {
		this.primero = primero;
	}

	public void setVidaMuro(int vidaMuro) {
		this.vidaMuro = vidaMuro;
	}

	public Aguila_Defender getWinCondition() {
		return winCondition;
	}

	public void setWinCondition(Aguila_Defender winCondition) {
		this.winCondition = winCondition;
	}

	public ArrayList<Muro> getMuros() {
		return muros;
	}

	public void setMuros(ArrayList<Muro> muros) {
		this.muros = muros;
	}

	public ArrayList<Tanque> getTanquesEnemigos() {
		return tanquesEnemigos;
	}

	public void setTanquesEnemigos(ArrayList<Tanque> tanquesEnemigos) {
		this.tanquesEnemigos = tanquesEnemigos;
	}

	public Jugador getJuga() {
		return juga;
	}

	public void setJuga(Jugador juga) {
		this.juga = juga;
	}

	public TanqueJugador getTanqueJugador() {
		return tanqueJugador;
	}

	public void setTanqueJugador(TanqueJugador tanqueJugador) {
		this.tanqueJugador = tanqueJugador;
	}

	public ArrayList<Bala> getBalas() {
		return balas;
	}

	public void setBalas(ArrayList<Bala> balas) {
		this.balas = balas;
	}

	public Bala getBala() {
		return bala;
	}

	public void setBala(Bala bala) {
		this.bala = bala;
	}

	public int getVidaMuro() {
		return vidaMuro;
	}

	public Tanque[] getTanques() {
		return tanques;
	}

	public void setTanques(Tanque[] tanques) {
		this.tanques = tanques;
	}
}
