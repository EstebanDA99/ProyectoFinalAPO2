package mundo;

public class Muro_Decoracion extends Muro {
	public static final String TIPO_MURO = "decoracion";
	private String tipoMuro;

	public Muro_Decoracion(int posx,int posy,int vid, String ima, boolean destru) {
		super(posx, posy, vid, ima, destru);
	}
}
