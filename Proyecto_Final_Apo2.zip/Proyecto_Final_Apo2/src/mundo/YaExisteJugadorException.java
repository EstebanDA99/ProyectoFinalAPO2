package mundo;

public class YaExisteJugadorException extends Exception{
	/**
	 * El nombre del jugador que ya existe
	 */
	private String codigoYaExiste;
	/**
	 * El mensaje corto que indica que ocurri�
	 */
	private String mensaje;

	
	public YaExisteJugadorException(String mens, String codYaExiste) {
		mensaje = mens;
		codigoYaExiste = codYaExiste;
	}

	/**
	 * Retorna una cadena con el c�digo
	 * 
	 * @return el c�digo que ya existe
	 */
	public String darCodigoYaExiste() {
		return codigoYaExiste;
	}

	public String darMensaje() {
		return mensaje;
	}
}
