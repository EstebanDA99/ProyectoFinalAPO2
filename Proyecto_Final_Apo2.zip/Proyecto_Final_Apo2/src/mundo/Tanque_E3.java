package mundo;

public class Tanque_E3 extends Tanque{

	public Tanque_E3(int posx, int posy,int recom) {
		super(posx, posy, recom);
		// TODO Auto-generated constructor stub
	}

}
