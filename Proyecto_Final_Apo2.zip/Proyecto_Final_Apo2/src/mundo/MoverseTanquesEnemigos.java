package mundo;

public interface MoverseTanquesEnemigos {

	public void moverse(int moverse);
	public void choco(String mensaje);
}

