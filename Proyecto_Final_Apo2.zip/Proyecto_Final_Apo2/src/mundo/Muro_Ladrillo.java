package mundo;

public class Muro_Ladrillo extends Muro implements Destruido{
	public static final String MURO_DESTRUIDO="./data/sprites/MuroDestruido.png";
	public static final String MURO_DESTRUIDO2="./data/sprites/MuroDestruido2.png";
	public static final String MURO_DESTRUIDO_ARRIBA="./data/sprites/MuroDestruidoArriba.png";
	public static final String MURO_DESTRUIDO2_ARRIBA="./data/sprites/MuroDestruido2Arriba.png";
	public static final String MURO_DESTRUIDO_ABAJO="./data/sprites/MuroDestruidoAbajo.png";
	public static final String MURO_DESTRUIDO2_ABAJO="./data/sprites/MuroDestruido2Abajo.png";
	public static final String MURO_DESTRUIDO_IZQUIERDA="./data/sprites/MuroDestruidoIzquierda.png";
	public static final String MURO_DESTRUIDO2_IZQUIERDA="./data/sprites/MuroDestruido2Izquierda.png";

	private int vida;
	private String imagenACambiar;
	private int posx;
	private int posy;
	private int ancho;
	private int alto;
	private boolean destruido;
	public Muro_Ladrillo(int vid, String ima, boolean destru, int posX, int posY, int anch, int alt) {
		super(posX, posY, vid, ima, destru);
		vida=vid;
		imagenACambiar=ima;
		posx=posX;
		posy=posY;
		ancho=anch;
		alto=alt;
		destruido=destru;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public String getImagenACambiar() {
		return imagenACambiar;
	}
	public void setImagenACambiar(String imagenACambiar) {
		this.imagenACambiar = imagenACambiar;
	}
	public int getPosx() {
		return posx;
	}
	public void setPosx(int posx) {
		this.posx = posx;
	}
	public int getPosy() {
		return posy;
	}
	public void setPosy(int posy) {
		this.posy = posy;
	}
	public int getAncho() {
		return ancho;
	}
	public void setAncho(int ancho) {
		this.ancho = ancho;
	}
	public int getAlto() {
		return alto;
	}
	public void setAlto(int alto) {
		this.alto = alto;
	}
	public void cambiarImagen(int i, String direccion) {
	if(vida-i==10) {
		if(direccion.equals("AVANZAR")){
		setImagenACambiar(MURO_DESTRUIDO_IZQUIERDA);
		}else if(direccion.equals("RETROCEDER")) {
			setImagenACambiar(MURO_DESTRUIDO);
		}else if(direccion.equals("ARRIBA")) {
			setImagenACambiar(MURO_DESTRUIDO_ABAJO);
		}else if(direccion.equals("ABAJO")) {
			setImagenACambiar(MURO_DESTRUIDO_ARRIBA);
		}
		this.setVida(10);
	}else if(vida-i==5) {
		if(direccion.equals("AVANZAR")){
			setImagenACambiar(MURO_DESTRUIDO2_IZQUIERDA);
		}else if(direccion.equals("RETROCEDER")) {
			setImagenACambiar(MURO_DESTRUIDO2);
		}else if(direccion.equals("ARRIBA")) {
			setImagenACambiar(MURO_DESTRUIDO2_ABAJO);
		}else if(direccion.equals("ABAJO")) {
			setImagenACambiar(MURO_DESTRUIDO2_ARRIBA);
		}
		setVida(5);
	}else if(vida-i==0) {
		setVida(0);
		this.setDestruido(true);
	}
	}
	
	public boolean isDestruido() {
		return destruido;
	}
	public void setDestruido(boolean destruido) {
		this.destruido = destruido;
	}
	@Override
	public boolean destruido() {
		boolean si=false;
		if(vida==0) {
			setDestruido(true);
			si=true;
		}
		return si;
	}
}
