package mundo;

import java.awt.Color;
import java.util.ArrayList;

public class Tanque implements  Disparar {
	// hacer distrubucion de responsabilidad con los tanques
	public static final String TANQUE_ENEMIGO = "./data/sprites/TanqueEnemigoArriba.png";
	public static final String TANQUE_ENEMIGO_ESPECIAL="./data/sprites/TanqueEnemigoEspecial.png";
	public static final String TANQUE_JUGADOR = "Jugador";
	public static final int VIDA_PROMEDIO = 5;
	public static final int MOVIMIENTO_TANQUE_NORMAL = 2;
	public static final int MOVIMIENTO_TANQUE_MEDIO = 3;
	public static final int MOVIMIENTO_TANQUE_MAYIR = 5;
	public static final int DANO_ATAQUE_MEDIO = 5;
	public static final int DANO_ATAQUE_MAXIMO = 10;
	public static final String CAMBIAR_IMAGEN_ENEMIGO = "sprite";
	public static final int AVANCE_NULO=0;
	private int vida;
	private int ataque;
	private String imagen;
	private int acumuladorDano;
	private int recompensa;
	private ArrayList<Bala> balas;

	public Tanque(int posx, int posy, int recom) {
		vida = VIDA_PROMEDIO;
		ataque = DANO_ATAQUE_MEDIO;
		imagen = CAMBIAR_IMAGEN_ENEMIGO;
		acumuladorDano = 0;
		balas = new ArrayList<Bala>();
		recompensa=recom;
	}
	// hacer interface colision para saber si ataco a algun tanque o a algun muro

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getAtaque() {
		return ataque;
	}

	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public int getAcumuladorDano() {
		return acumuladorDano;
	}

	public void setAcumuladorDano(int acumuladorDano) {
		this.acumuladorDano = acumuladorDano;
	}

	public int getRecompensa() {
		return recompensa;
	}

	public void setRecompensa(int recompensa) {
		this.recompensa = recompensa;
	}

	@Override
	public void disparar() {
		for (int i = 0; i < balas.size(); i++) {
			if (balas.get(i) != null) {
				balas.get(i).disparar();
				System.out.println(balas.get(i).getPosx());
			}
		}
	}
}
