package mundo;

public class Muro{
	public static final int VIDA_NORMAL = 15;
	public static final String IMAGEN = "./data/sprites/Muro.png";
	private int vida;
	private String imagen;
	private boolean destruido;
	private int posX;
	private int posY;

	public Muro(int posx, int posy,int vid, String ima, boolean destru) {
		vida = VIDA_NORMAL;
		imagen = IMAGEN;
		destruido = false;
		posX=posx;
		posY=posy;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public boolean isDestruido() {
		return destruido;
	}

	public void setDestruido(boolean destruido) {
		this.destruido = destruido;
	}

	
}
