package mundo;

import java.util.ArrayList;

public class Jugador {
	private TanqueJugador juga;
	private String nombre;
	private int puntaje;
	public Jugador() {
	}

	public Jugador(String nomb, int punta) {
		nombre = nomb;
		puntaje = punta;
	}

	public TanqueJugador getJuga() {
		return juga;
	}

	public void setJuga(TanqueJugador juga) {
		this.juga = juga;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPuntaje() {
		return puntaje;
	}

	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}
	public void acumularPuntaje(int p) {
		puntaje+=p;
	}

}