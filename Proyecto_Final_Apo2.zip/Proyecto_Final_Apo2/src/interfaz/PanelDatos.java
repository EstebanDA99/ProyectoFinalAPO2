package interfaz;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import hilos.HiloTiempo;

import java.awt.*;

public class PanelDatos extends JPanel {
	public static final String TIEMPO = "Tiempo:";
	public static final String PUNTAJE = "Puntaje:";
	public static final String ENEMIGOS_RESTANTES = "Enemigos Restantes:";
	private JLabel[] labels;
	private InterfazPrincipal principal;
	private JLabel puntaje;
	private JLabel enemigosRestantes;
	private JLabel tiempo;
	private JLabel tPuntaje;
	private JLabel tEnemigos;
	private JLabel tTiempo;
	private String minuto;
	private String segundo;

	public PanelDatos(InterfazPrincipal p) {
		principal = p;
		minuto = "00";
		segundo = "00";
		labels = new JLabel[6];
		tiempo = new JLabel(TIEMPO);
		tTiempo = new JLabel(minuto + ":" + segundo);
		puntaje = new JLabel(PUNTAJE);
		tPuntaje = new JLabel("0");
		enemigosRestantes = new JLabel(ENEMIGOS_RESTANTES);
		tEnemigos = new JLabel("0");
		inicializar();
	}

	public void setTiempo(int segundo, int minuto) {

		if (segundo < 10) {
			this.segundo = "0" + segundo;
		} else {
			this.segundo = segundo + "";
		}
		if (minuto < 10) {
			this.minuto = "0" + minuto;
		} else {
			this.minuto = minuto + "";
		}
		String mensaje = TIEMPO + this.minuto + ":" + this.segundo;
		tTiempo.setText(this.minuto + ":" + this.segundo);
	}

	public void setEnemigos(int enemigos) {
		tEnemigos.setText(enemigos + "");
	}

	public void setPuntaje(int punta) {
		tPuntaje.setText(punta + "");
	}

	public String gettTiempo() {
		return tTiempo.getText();
	}

	public void inicializar() {
		this.setLayout(new GridLayout(1, labels.length));
		int k = 0;
		JLabel[] contenedor = { puntaje, tPuntaje, enemigosRestantes, tEnemigos, tiempo, tTiempo };
		for (int j = 0; j < labels.length; j++) {
			labels[j] = contenedor[j];
		}
		for (int j = 0; j < labels.length; j++) {
			Border border = BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.BLACK, Color.BLACK);
			labels[j].setBorder(border);
			add(labels[j]);
		}
	}

}
