package interfaz;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;

import hilos.*;
import mundo.*;

public class InterfazPrincipal extends JDialog {
	public static final String MAPA1 = "./data/mapas/primerMapa.txt";
	public static final String MAPA2 = "./data/mapas/segundoMapa.txt";
	public static final String MAPA3 = "./data/mapas/tercerMapa.txt";
	private PanelEscenario matriz;
	private PanelDatos info;
	private HiloJugador hilo;
	private HiloTiempo hilos;
	private Tablero table;
	private int indice;
	private int cantidadEnJuego;
	private Tanque[] tanquesInterfaz;
	private Puntaje P;

	public InterfazPrincipal() {
		setSize(700, 720);
		setResizable(false);
		setTitle("City Tank Escenario");
		inicializar();
		setLocationRelativeTo(null);
		try {
			cargarJuego();
			tanquesInterfaz = table.getTanques();
		} catch (Exception e) {
			// TODO: handle exception
		}
		iniciarHilo();
		agregarTanques();
		inicializarTiempo(info);
		JPanel aux = new JPanel();
		aux.setLayout(new BorderLayout());
		aux.add(matriz, BorderLayout.CENTER);
		aux.add(info, BorderLayout.NORTH);
		add(aux);
	}

	public void inicializar() {
		this.setLayout(new GridLayout());
		indice = 0;
		cantidadEnJuego = 0;
		indice = 0;
		table = new Tablero();
		matriz = new PanelEscenario(this);
		matriz.setBackground(Color.WHITE);
		info = new PanelDatos(this);

	}

	public void iniciarHilo() {
		hilo = new HiloJugador(this, obtenerTablero());
		hilo.start();
		this.refrescar();
	}

	public void refrescar() {
		matriz.repaint();
		info.setEnemigos(table.getTanquesEnemigos().size());
		info.setPuntaje(table.getJuga().getPuntaje());
	}

	public void agregarBala(int posx, int posy, String direccion, String mensaje) {
		Bala nueva = table.agregarBala(posx, posy, direccion);
		if (mensaje.equals("JUGADOR")) {
			HiloBala iniciar = new HiloBala(this, nueva);
			iniciar.start();
		} else if (mensaje.equals("TANQUE")) {
			nueva.setTanque(true);
			nueva.setAvance(2);
			HiloBala iniciar = new HiloBala(this, nueva);
			iniciar.start();
		} else if (mensaje.equals("TANQUE_ESPECIAL")) {
			nueva.setTanque(true);
			nueva.setAvance(5);
			HiloBala iniciar = new HiloBala(this, nueva);
			iniciar.start();
		}
	}

	public void inicializarTiempo(PanelDatos panel) {
		hilos = new HiloTiempo(panel, this);
		hilos.start();
	}

	public void agregarTanques() {
		boolean termino = false;
		for (int i = 0; i < tanquesInterfaz.length && !termino; i++) {
			if (tanquesInterfaz[indice] != null && indice < tanquesInterfaz.length) {
				if (indice != 13) {
					if (tanquesInterfaz[indice] instanceof Tanque_E1) {
						Tanque_E1 actu = (Tanque_E1) tanquesInterfaz[indice];
						HiloRaspawn nuevo = new HiloRaspawn(this, actu, table);
						nuevo.start();
						cantidadEnJuego++;
						indice++;
					} else if (tanquesInterfaz[indice] instanceof Tanque_E2) {
						Tanque_E2 actu = (Tanque_E2) tanquesInterfaz[indice];
						HiloRaspawn nuevo = new HiloRaspawn(this, actu, table);
						nuevo.start();
						cantidadEnJuego++;
						indice++;
					}
				}
			}
			if (cantidadEnJuego == 3) {
				termino = true;
			}
		}

	}

	public void dispararTanque() {
		int numero = (int) (Math.random() * 3) + 1;
		if (numero == 3) {
			numero += -1;
		}
		int posx = 0;
		int posy = 0;
		if (table.getTanquesEnemigos().get(numero) instanceof Tanque_E1) {
			Tanque_E1 actual = (Tanque_E1) table.getTanquesEnemigos().get(numero);
			posx = actual.getPosX() + 10;
			posy = actual.getPosY() + 10;
			String mensaje = "";
			if (actual.getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_DERECHA)) {
				mensaje = "AVANZAR";
			} else if (actual.getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_IZQUIERDA)) {
				mensaje = "RETROCEDER";
			} else if (actual.getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_ARRIBA)) {
				mensaje = "ARRIBA";
			} else if (actual.getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_ABAJO)) {
				mensaje = "ABAJO";
			}
			matriz.disparo = true;
			agregarBala(posx, posy, mensaje, "TANQUE");
		} else if (table.getTanquesEnemigos().get(numero) instanceof Tanque_E2) {
			Tanque_E2 actual = (Tanque_E2) table.getTanquesEnemigos().get(numero);
			posx = actual.getPosX() + 10;
			posy = actual.getPosY() + 10;
			String mensaje = "";
			if (actual.getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_DERECHA)) {
				mensaje = "AVANZAR";
			} else if (actual.getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_IZQUIERDA)) {
				mensaje = "RETROCEDER";
			} else if (actual.getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_ARRIBA)) {
				mensaje = "ARRIBA";
			} else if (actual.getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_ABAJO)) {
				mensaje = "ABAJO";
			}
			matriz.disparo = true;
			agregarBala(posx, posy, mensaje, "TANQUE_ESPECIAL");
		}
	}

	public void cargarJuego() throws Exception {
		File archivoTablero = new File("./data/mapas/tercerMapa.txt");
		try {
			table.cargarEscenario(archivoTablero);
		} catch (Exception e) {

			JOptionPane.showMessageDialog(this, e.getMessage());
		}
		
	}

	public void guardarJuego() {
		File archivoDestino = new File("./data/JuegoGuardado/Guardar.txt");
		try {
			table.guardar(archivoDestino);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "No se pudo guardar");
		}
	}

	public void guardarSerializado() {
		File ruta = new File("./data/Jugadores/Jugadores.txt");
		try {
			table.guardarJugadoresSerializado(ruta);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "Hubo un error al guardar serializadamente");
		}
	}

	public String obtenerTiempo() {
		String mensaje = info.gettTiempo();
		return mensaje;
	}

	public String obtenerMensaje() {
		String retorno = matriz.obtenerString();
		return retorno;
	}

	public Tablero obtenerTablero() {
		return table;
	}

	public void perdio() throws IOException {
		matriz.sepuede = false;
		refrescar();
		obtenerTablero().getWinCondition().setVida(0);
		String name = JOptionPane.showInputDialog("Digite su nombre, por favor");
		int puntaje = obtenerTablero().getJuga().getPuntaje();
		Puntaje nuevo = new Puntaje(name, puntaje, obtenerTiempo());
		try {
			obtenerTablero().agregarJugador(nuevo);
			obtenerTablero().guardarRanqueo();
			guardarSerializado();
		} catch (YaExisteJugadorException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	public static void main(String[] args) {
		InterfazPrincipal princi = new InterfazPrincipal();
		princi.setVisible(true);
	}

	public int obtenerAnchoActual() {
		return getContentPane().getWidth();
	}

	public int obtenerAltoActual() {
		return getContentPane().getHeight();
	}

	public void eliminaronTanque() {
		cantidadEnJuego--;
		matriz.setCantidadActual(cantidadEnJuego);
	}

	public int getIndice() {
		return indice;
	}

	public void setIndice(int indice) {
		this.indice = indice;
	}

	public int getCantidadEnJuego() {
		return cantidadEnJuego;
	}

	public void setCantidadEnJuego(int cantidadEnJuego) {
		this.cantidadEnJuego = cantidadEnJuego;
	}

	public PanelDatos getInfo() {
		return info;
	}

	public void setInfo(PanelDatos info) {
		this.info = info;
	}

	public Puntaje getP() {
		return P;
	}

	public void setP(Puntaje p) {
		P = p;
	}

}
