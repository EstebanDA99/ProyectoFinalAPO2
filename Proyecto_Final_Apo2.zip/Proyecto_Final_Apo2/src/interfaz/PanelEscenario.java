package interfaz;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.*;
import mundo.*;

public class PanelEscenario extends JPanel implements MouseListener, KeyListener {
	private InterfazPrincipal principal;
	private String direccion;
	private String mensaje;
	private String mensajeDisparo;
	private int posXT;
	private int posYT;
	boolean listoDisparo, disparo = false;
	boolean sepuede;
	int posx;
	int posy;
	private int cantidadActual;

	public PanelEscenario(InterfazPrincipal ventana) {
		principal = ventana;
		addKeyListener(this);
		addMouseListener(this);
		mensaje = "";
		setFocusable(true);
		requestFocusInWindow();
		sepuede = false;
	}

	@Override
	public void paintComponent(Graphics g) {
		posXT = principal.obtenerTablero().getTanqueJugador().getPosX();
		posYT = principal.obtenerTablero().getTanqueJugador().getPosY();
		setBackground(Color.BLACK);
		removeAll();
		cantidadActual = 0;
		super.paintComponent(g);
		direccion = principal.obtenerTablero().getTanqueJugador().getImagen();

		ImageIcon icono = new ImageIcon(direccion);
		Graphics2D g2 = (Graphics2D) g;
		g2.drawImage(icono.getImage(), posXT, posYT, 30, 30, null);

		ArrayList<Muro> muritos = principal.obtenerTablero().getMuros();
		for (int i = 0; i < muritos.size(); i++) {
			if (muritos.get(i) != null) {
				if (muritos.get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo nuevo = (Muro_Ladrillo) muritos.get(i);
					if (nuevo.isDestruido() != true) {
						ImageIcon muro = new ImageIcon(nuevo.getImagenACambiar());
						g2.drawImage(muro.getImage(), nuevo.getPosx(), nuevo.getPosy(), 30, 30, null);
					}
				} else if (muritos.get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible actu = (Muro_Indestructible) muritos.get(i);
					ImageIcon iconoMuro = new ImageIcon(actu.getImagen());
					g2.drawImage(iconoMuro.getImage(), actu.getPosX(), actu.getPosY(), 30, 30, null);
				}
				if (principal.obtenerTablero().getWinCondition() != null) {
					Aguila_Defender def = principal.obtenerTablero().getWinCondition();
					ImageIcon ic = new ImageIcon(def.getImagen());
					g2.drawImage(ic.getImage(), def.getPosX(), def.getPosY(), 30, 30, null);
				}
			}
		}

		ArrayList<Tanque> tanq = principal.obtenerTablero().getTanquesEnemigos();
		boolean termino = false;
		for (int i = 0; i < tanq.size() && !termino; i++) {
			if (tanq.get(i) != null) {
				if (tanq.get(i) instanceof Tanque_E1) {
					Tanque_E1 actu = (Tanque_E1) tanq.get(i);
					ImageIcon nuevo = new ImageIcon(actu.getImagen());
					g2.drawImage(nuevo.getImage(), actu.getPosX(), actu.getPosY(), 30, 30, null);
					cantidadActual++;
				} else if (tanq.get(i) instanceof Tanque_E2) {
					Tanque_E2 actu = (Tanque_E2) tanq.get(i);
					ImageIcon nuevo = new ImageIcon(actu.getImagen());
					g2.drawImage(nuevo.getImage(), actu.getPosX(), actu.getPosY(), 30, 30, null);
					cantidadActual++;
				}
			}
			if (cantidadActual == 3) {
				termino = true;
			}
		}

		if (disparo) {
			ArrayList<Bala> balitas = principal.obtenerTablero().getBalas();
			for (int i = 0; i < balitas.size(); i++) {
				Bala bal = balitas.get(i);
				if (bal.isEstado() == true) {
					ImageIcon balar = new ImageIcon(balitas.get(i).getImagen());
					g2.drawImage(balar.getImage(), bal.getPosx(), bal.getPosy(), 10, 10, null);
				}
			}
		}
		g2.setColor(Color.CYAN);


	}

	public String obtenerString() {
		return mensaje;
	}

	public String obtenerMensajeBala() {
		return mensajeDisparo;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (!sepuede) {
			if (e.getKeyCode() == 37) { // left
				principal.obtenerTablero().getTanqueJugador().setImagen(TanqueJugador.IZQUIERDA);
				direccion = principal.obtenerTablero().getTanqueJugador().getImagen();
				mensaje = "RETROCEDER";
				principal.obtenerTablero().getTanqueJugador().setDetenerse(false);
			} else if (e.getKeyCode() == 39) { // right
				principal.obtenerTablero().getTanqueJugador().setImagen(TanqueJugador.DERECHA);
				direccion = principal.obtenerTablero().getTanqueJugador().getImagen();
				mensaje = "AVANZAR";
				principal.obtenerTablero().getTanqueJugador().setDetenerse(false);
			} else if (e.getKeyCode() == 38) { // up
				principal.obtenerTablero().getTanqueJugador().setImagen(TanqueJugador.ARRIBA);
				direccion = principal.obtenerTablero().getTanqueJugador().getImagen();
				mensaje = "ARRIBA";
				principal.obtenerTablero().getTanqueJugador().setDetenerse(false);
			} else if (e.getKeyCode() == 40) { // down
				principal.obtenerTablero().getTanqueJugador().setImagen(TanqueJugador.ABAJO);
				direccion = principal.obtenerTablero().getTanqueJugador().getImagen();
				mensaje = "ABAJO";
				principal.obtenerTablero().getTanqueJugador().setDetenerse(false);
			} else if (e.getKeyCode() == 32) {
				if (!listoDisparo) {
					listoDisparo = true;
					if (listoDisparo) {
						posx = posXT + 10;
						posy = posYT + 10;
						principal.agregarBala(posx, posy, mensaje, "JUGADOR");
						disparo = true;
					}
				}
			}

			repaint();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == 32) {
			listoDisparo = false;
			if (posx < 0 || posx > 700 || posy > 700 || posy < 0) {
				Rectangle bala = new Rectangle(0, 0, 0, 0);
				disparo = false;
				listoDisparo = true;
			}
			if (e.getKeyCode() == 37) {
				principal.obtenerTablero().getTanqueJugador().setDetenerse(false);
			} else if (e.getKeyCode() == 38) {
				principal.obtenerTablero().getTanqueJugador().setDetenerse(false);
			} else if (e.getKeyCode() == 39) {
				principal.obtenerTablero().getTanqueJugador().setDetenerse(false);
			} else if (e.getKeyCode() == 40) {
				principal.obtenerTablero().getTanqueJugador().setDetenerse(false);
			}
		}

	}

	@Override
	public void keyTyped(KeyEvent arg0) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}

	public int getCantidadActual() {
		return cantidadActual;
	}

	public void setCantidadActual(int cantidadActual) {
		this.cantidadActual = cantidadActual;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		principal.guardarJuego();
		System.out.println(arg0.getX() + " " + arg0.getY());
		repaint();
	}
}
