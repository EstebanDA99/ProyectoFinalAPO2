package pruebas;
import mundo.*;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class PruebasMundo {
	private Tablero t;
	@Test
	public void setUpEscenarioTanque() {
		t=new Tablero();
	}
	@Test
	public void pruebaMoverTanqueJugador() {
		setUpEscenarioTanque();
		TanqueJugador actual=new TanqueJugador(300,300,t,30,200);
		actual.cambiarSentido("AVANZAR");
		assertTrue(actual.getPosX()==302);
	}
	@Test
	public void pruebaTanque_E1() {
		setUpEscenarioTanque();
		Tanque_E1 actual=new Tanque_E1(5, 300, 300, "data/sprites/TanqueEnemigoArriba.png", 7, false,100);
		actual.moverse(0);
		assertTrue(actual.getPosY()==(actual.getPosX()+actual.getAvance()));
		assertEquals(actual.getImagen(),Tanque_E1.TANQUE_ENEMIGO_ABAJO);
	}
	@Test
	public void pruebaTanque_E2() {
		setUpEscenarioTanque();
		Tanque_E2 actual=new Tanque_E2(15, "data/sprites/TanqueEspecial", 10, 500, 600, false,200);
		actual.moverse(3);
		assertTrue(actual.getPosX()==490);
		assertEquals(actual.getImagen(),Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_IZQUIERDA);
	}
	@Test
	public void pruebaMuro_Ladrillo() {
		setUpEscenarioTanque();
		Muro_Ladrillo actual=new Muro_Ladrillo(15, "./data/sprites/MuroDestruido.png", false, 300, 500, 30, 30);
		actual.cambiarImagen(10, "ARRIBA");
		assertTrue(actual.getVida()==5);
		assertEquals(actual.getImagenACambiar(),Muro_Ladrillo.MURO_DESTRUIDO2_ABAJO);
		assertTrue(actual.isDestruido()==false);
	}
	@Test
	public void pruebaMuro_Ladrillo2() {
		setUpEscenarioTanque();
		Muro_Ladrillo actual=new Muro_Ladrillo(0, "./data/sprites/MuroDestruido.png", true, 300, 300, 30, 30);
		actual.destruido();
		assertTrue(actual.destruido()==true);
	}
	@Test
	public void pruebaBalaAvanzar() {
		setUpEscenarioTanque();
		Bala actual=new Bala(20, 30, "AVANZAR");
		actual.disparar();
		assertTrue(actual.getPosx()==21);
	}
	//Implementar en los tanques enemigos
//	@Test
//	public void pruebaDisparar() {
//		setUpEscenarioTanque();
//		Bala actual=new Bala(200, 300, "AVANZAR");
//		Bala actual2=new Bala(100, 300, "RETROCEDER");
//		Bala actual3=new Bala(50, 2, "ARRIBA");
//		Bala actual4=new Bala(6, 8, "ABAJO");
//		t.getBalas().add(actual);
//		t.getBalas().add(actual2);
//		t.getBalas().add(actual3);
//		t.getBalas().add(actual4);
//		Tanque nuevo=new Tanque(200, 300);
//		nuevo.disparar();
//		assertTrue(t.getBalas().get(1).getPosx()==99);
//		
//	}
	@Test
	public void PruebaBusquedBinaria() {
	setUpEscenarioTanque();
	Muro_Ladrillo nuevo=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo10=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo9=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo8=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo7=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo6=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo5=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo4=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo3=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	Muro_Ladrillo nuevo2=new Muro_Ladrillo(50, Muro_Ladrillo.MURO_DESTRUIDO, false, 300, 500, 30, 30);
	t.getMuros().add(nuevo2);
	t.getMuros().add(nuevo9);
	t.getMuros().add(nuevo8);
	t.getMuros().add(nuevo7);
	t.getMuros().add(nuevo6);
	t.getMuros().add(nuevo5);
	t.getMuros().add(nuevo4);
	t.getMuros().add(nuevo3);
	t.getMuros().add(nuevo);
	t.getMuros().add(nuevo10);
	int num=t.BuscarMuroBinario(5);
	assertTrue(num==5);
	}
	@Test
	public void pruebaGuardarJugador() throws YaExisteJugadorException {
		setUpEscenarioTanque();
		Puntaje nuevo=new Puntaje("JUAN", 300, "05:44");
		t.agregarJugador(nuevo);
		Puntaje encontrado=t.buscarJugadorRecursivo("JUAN",t.getPrimero());
		assertTrue(encontrado.getNombreJugador().equals("JUAN"));
	}
	@Test 
	public void probarEliminar() throws YaExisteJugadorException {
		setUpEscenarioTanque();
		Puntaje nuevo=new Puntaje("JUAN", 300, "05:44");
		t.agregarJugador(nuevo);
		boolean encontrado=t.eliminarJugador("JUAN");
		assertTrue(encontrado==true);
	}
	@Test
	public void pruebaBuscarMejorPuntaje() throws YaExisteJugadorException {
		setUpEscenarioTanque();
		Puntaje nuevo=new Puntaje("RIAS",Integer.MAX_VALUE,"05:044");
		t.agregarJugador(nuevo);
		Puntaje retornado=t.buscarMejorPuntajeRecursivo(t.getPrimero(), t.getPrimero().getSiguiente(),null);
		assertTrue(retornado.getNombreJugador()=="RIAS");
	}
	@Test
	public void PruebaRankeo() throws YaExisteJugadorException {
		setUpEscenarioTanque();
		Puntaje nuevo=new Puntaje("RIAS",Integer.MAX_VALUE,"05:044");
		t.agregarJugador(nuevo);
		Puntaje[] ranked=t.mostrarRanked(t.getPrimero());
		System.out.println(ranked[0].getNombreJugador());
		assertTrue(ranked[0]!=null);
	}
}
