package interfazPresentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class PanelPresentacion extends JPanel implements ActionListener {
	public static final String INICIAR_JUEGO = "Iniciar Juego";
	public static final String CARGAR_PUNTAJES = "Cargar Puntajes";
	public static final String LISTA_JUGADORES = "Mejor Jugador";
	private JButton iniciar;
	private JButton mostrarPuntajes;
	private JLabel imagen;
	private JButton mostrarListaJugadores;
	private Principal interfaz;

	public PanelPresentacion(Principal ventana) {
		this.setBackground(Color.BLACK);
		interfaz = ventana;
		inicializar();
	}

	public void inicializar() {

		iniciar = new JButton(INICIAR_JUEGO);
		iniciar.setActionCommand(INICIAR_JUEGO);
		iniciar.addActionListener(this);
		iniciar.setForeground(Color.YELLOW);
		iniciar.setBackground(Color.BLACK);

		mostrarPuntajes = new JButton(CARGAR_PUNTAJES);
		mostrarPuntajes.setActionCommand(CARGAR_PUNTAJES);
		mostrarPuntajes.addActionListener(this);
		mostrarPuntajes.setForeground(Color.YELLOW);
		mostrarPuntajes.setBackground(Color.BLACK);

		mostrarListaJugadores = new JButton(LISTA_JUGADORES);
		mostrarListaJugadores.setActionCommand(LISTA_JUGADORES);
		mostrarListaJugadores.addActionListener(this);
		mostrarListaJugadores.setForeground(Color.YELLOW);
		mostrarListaJugadores.setBackground(Color.BLACK);

		imagen = new JLabel();
		ImageIcon icono = new ImageIcon("data/sprites/Fondo.png");
		imagen.setIcon(icono);

		JPanel aux = new JPanel();
		aux.add(imagen, BorderLayout.CENTER);
		aux.setBackground(Color.BLACK);

		JPanel aux2 = new JPanel();
		aux2.setLayout(new GridLayout(3, 1));
		aux2.add(iniciar);
		aux2.add(mostrarPuntajes);
		aux2.add(mostrarListaJugadores);

		JPanel contenedora = new JPanel();
		contenedora.setLayout(new BorderLayout());
		contenedora.add(aux, BorderLayout.NORTH);
		contenedora.add(aux2, BorderLayout.CENTER);
		add(contenedora);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String comando = arg0.getActionCommand();
		if (comando.equals(INICIAR_JUEGO)) {
			interfaz.iniciarInterfaz();
		} else if (comando.equals(CARGAR_PUNTAJES)) {
			interfaz.cargarPuntajes();
		}else if(comando.equals(LISTA_JUGADORES)) {
			
			String mensaje=interfaz.mostrarRanked();
			JOptionPane.showMessageDialog(this, mensaje);
		}
	}
}
