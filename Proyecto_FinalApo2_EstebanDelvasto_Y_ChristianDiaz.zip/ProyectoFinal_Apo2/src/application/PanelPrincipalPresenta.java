package application;

import java.awt.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javax.swing.*;

import mundo.Puntaje;

import java.awt.*;

public class PanelPrincipalPresenta extends JFrame {
	private PanelPresentacion pre;
	private InterfazController iniciar;
	private PanelInformacion info;
	private Puntaje obtenido;
	private Puntaje[] ranked;
	public PanelPrincipalPresenta() {
		this.setBackground(Color.BLACK);
		setTitle("Menu");
		inicializar();
		try {
			obtenido = iniciar.getP();
		} catch (Exception e) {
			// TODO: handle exception
		}
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();

	}

	public void leerPuntaje() throws IOException, ClassNotFoundException {
		ObjectInputStream leer = new ObjectInputStream(new FileInputStream("./data/Jugadores/Jugadores.txt"));
		obtenido = (Puntaje) leer.readObject();
		leer.close();
	}
	public void leerRanked() throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream leer = new ObjectInputStream(new FileInputStream("./data/Jugadores/Ranked.txt"));
		ranked = (Puntaje[]) leer.readObject();
		leer.close();
	}

	public void inicializar() {
		pre = new PanelPresentacion(this);
		add(pre);
	}

	public void iniciarInterfaz() {
		iniciar = new InterfazController();
		iniciar.setVisible(true);
	}

	public void cargarPuntajes() {
		try {
			leerPuntaje();
			info = new PanelInformacion(obtenido);
			info.setVisible(true);
			info.setLocationRelativeTo(null);
			info.pack();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "No se puede cargar por que no has cargado el mundo");
		}

	}
	public String mostrarRanked() {
		try {
			leerRanked();
		} catch (Exception e) {
			// TODO: handle exception
		}
		String mensaje="";
		for (int i = 0; i < ranked.length; i++) {
			mensaje+="Puesto#"+(i+1)+" "+ranked[i].getNombreJugador()+" con "+ranked[i].getPuntajeJugador()+" puntos."+"\n";
		}
		return mensaje;
	}

	public static void main(String[] args) {
		PanelPrincipalPresenta pro = new PanelPrincipalPresenta();
		pro.setResizable(false);
		pro.setVisible(true);
	}

}
