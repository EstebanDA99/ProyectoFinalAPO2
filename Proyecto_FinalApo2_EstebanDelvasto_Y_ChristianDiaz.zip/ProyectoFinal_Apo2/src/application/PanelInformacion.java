package application;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import mundo.Puntaje;

public class PanelInformacion extends JDialog {
	private JLabel[][] matriz;
	private Puntaje punta;
	int numero;

	public PanelInformacion(Puntaje primero) {
		matriz = new JLabel[10][4];
		numero = 1;
		punta = primero;
		empezarMatriz();

	}

	public void empezarMatriz() {
		this.setLayout(new GridLayout(matriz.length, matriz[0].length));
		this.setBackground(Color.BLACK);
		String[] nombres = { "#Jugador", "Nombre", "Puntaje", "Tiempo" };
		for (int i = 0; i < matriz.length; i++) {
			if (i == 0) {
				for (int j = 0; j < nombres.length; j++) {
					JLabel label = new JLabel(nombres[j]);
					matriz[i][j] = label;
				}
			} else {
				for (int j = 0; j < matriz[0].length; j++) {
					if (punta != null) {
						if (j == 0) {
							JLabel label = new JLabel(numero + "");
							matriz[i][j] = label;
						} else if (j == 1) {
							JLabel label = new JLabel(punta.getNombreJugador());
							matriz[i][j] = label;
						} else if (j == 2) {
							JLabel label = new JLabel(punta.getPuntajeJugador() + "");
							matriz[i][j] = label;
						} else if (j == 3) {
							JLabel label = new JLabel(punta.getTiempo());
							matriz[i][j] = label;
						}
					} else {
						JLabel label = new JLabel(" ");
						matriz[i][j] = label;
					}
				}
				numero++;
				try {
					punta = punta.getSiguiente();
				} catch (Exception e) {
					// TODO: handle exception
					
				}
			}
		}
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				Border border = BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.BLACK, Color.BLACK);
				matriz[i][j].setBorder(border);
				add(matriz[i][j]);
			}
		}
	}
}
