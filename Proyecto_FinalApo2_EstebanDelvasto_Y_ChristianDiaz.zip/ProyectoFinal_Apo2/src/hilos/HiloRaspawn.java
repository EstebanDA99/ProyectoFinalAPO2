package hilos;

import mundo.*;
import application.InterfazController;

public class HiloRaspawn extends Thread {
	private InterfazController principal;
	private Tanque ta;
	private Tablero escenario;

	public HiloRaspawn(InterfazController p, Tanque tablero, Tablero t) {
		principal = p;
		ta = tablero;
		escenario = t;
	}

	public void run() {
		while (principal.obtenerTablero().getTanquesEnemigos().size() != 0
				&& principal.obtenerTablero().getTanqueJugador().getVida() == 5) {
			if (ta != null) {
				if (ta instanceof Tanque_E1) {
					if (!derecha() || !izquierda() || !arriba() || !abajo()) {
						((Tanque_E1) ta).moverse(((Tanque_E1) ta).getSeMueve());
					}
					if (((Tanque_E1) ta).getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_DERECHA)) {
						if (derecha()) {
							((Tanque_E1) ta).choco("DERECHA");
						}
					} else if (((Tanque_E1) ta).getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_IZQUIERDA)) {
						if (izquierda()) {
							((Tanque_E1) ta).choco("IZQUIERDA");
						}
					} else if (((Tanque_E1) ta).getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_ARRIBA)) {
						if (arriba()) {
							((Tanque_E1) ta).choco("ARRIBA");
						}
					} else if (((Tanque_E1) ta).getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_ABAJO)) {
						if (abajo()) {
							((Tanque_E1) ta).choco("ABAJO");
						}
					}

				} else if (ta instanceof Tanque_E2) {
					if (!derechaEspecial() || !izquierdaEspecial() || !arribaEspecial() || !abajoEspecial()) {
						((Tanque_E2) ta).moverse(((Tanque_E2) ta).getSeMueve());
					}
					if (((Tanque_E2) ta).getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_DERECHA)) {
						if (derechaEspecial()) {
							((Tanque_E2) ta).choco("DERECHA");
						}
					} else if (((Tanque_E2) ta).getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_IZQUIERDA)) {
						if (izquierdaEspecial()) {
							((Tanque_E2) ta).choco("IZQUIERDA");
						}
					} else if (((Tanque_E2) ta).getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_ARRIBA)) {
						if (arribaEspecial()) {
							((Tanque_E2) ta).choco("ARRIBA");
						}
					} else if (((Tanque_E2) ta).getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_ABAJO)) {
						if (abajoEspecial()) {
							((Tanque_E2) ta).choco("ABAJO");
						}
					}
				}
			}
			try {
				sleep(60);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

	public boolean derecha() {
		boolean choco = false;
		if (ta instanceof Tanque_E1 && ta.getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_DERECHA)) {
			for (int i = 0; i < escenario.getMuros().size(); i++) {
				if (escenario.getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) escenario.getMuros().get(i);
					if (((Tanque_E1) ta).getPosX() + 30 >= ma.getPosx()
							&& ((Tanque_E1) ta).getPosX() <= ma.getPosx() + 30) {
						if (((Tanque_E1) ta).getPosY() + 30 >= ma.getPosy()
								&& ((Tanque_E1) ta).getPosY() <= ma.getPosy() + 30) {
							((Tanque_E1) ta).choco1("DERECHA", ma.getPosx() - 31, ma.getPosy());
							choco = true;
						}
					}

				} else if (escenario.getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) escenario.getMuros().get(i);
					if (((Tanque_E1) ta).getPosX() + 30 >= ma.getPosX()
							&& ((Tanque_E1) ta).getPosX() <= ma.getPosX() + 30) {
						if (((Tanque_E1) ta).getPosY() + 30 >= ma.getPosY()
								&& ((Tanque_E1) ta).getPosY() <= ma.getPosY() + 30) {
							((Tanque_E1) ta).choco1("DERECHA", ma.getPosX() - 31, ma.getPosY());
							choco = true;
						}
					}
				}
			}
		}

		return choco;
	}

	public boolean derechaEspecial() {
		boolean choco = false;
		if (ta instanceof Tanque_E2 && ((Tanque_E2) ta).getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_DERECHA)) {
			for (int i = 0; i < escenario.getMuros().size(); i++) {
				if (escenario.getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) escenario.getMuros().get(i);
					if (((Tanque_E2) ta).getPosX() + 30 >= ma.getPosx()
							&& ((Tanque_E2) ta).getPosX() <= ma.getPosx() + 30) {
						if (((Tanque_E2) ta).getPosY() + 30 >= ma.getPosy()
								&& ((Tanque_E2) ta).getPosY() <= ma.getPosy() + 30) {
							((Tanque_E2) ta).choco1("DERECHA", ma.getPosx() - 31, ma.getPosy());
							choco = true;
						}
					}
				} else if (escenario.getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) escenario.getMuros().get(i);
					if (((Tanque_E2) ta).getPosX() + 30 >= ma.getPosX()
							&& ((Tanque_E2) ta).getPosX() <= ma.getPosX() + 30) {
						if (((Tanque_E2) ta).getPosY() + 30 >= ma.getPosY()
								&& ((Tanque_E2) ta).getPosY() <= ma.getPosY() + 30) {
							((Tanque_E2) ta).choco1("ABAJO", ma.getPosX() - 31, ma.getPosY());
							choco = true;
						}
					}

				}

			}
		}
		return choco;
	}

	public boolean izquierda() {
		boolean choco = false;
		if (ta instanceof Tanque_E1 && ta.getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_IZQUIERDA)) {
			for (int i = 0; i < escenario.getMuros().size(); i++) {
				if (escenario.getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) escenario.getMuros().get(i);
					if (((Tanque_E1) ta).getPosX() + 30 >= ma.getPosx()
							&& ((Tanque_E1) ta).getPosX() <= ma.getPosx() + 30) {
						if (((Tanque_E1) ta).getPosY() + 30 >= ma.getPosy()
								&& ((Tanque_E1) ta).getPosY() <= ma.getPosy() + 30) {
							((Tanque_E1) ta).choco1("IZQUIERDA", ma.getPosx() + 31, ma.getPosy());
							choco = true;
						}
					}
				} else if (escenario.getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) escenario.getMuros().get(i);
					if (((Tanque_E1) ta).getPosX() + 30 >= ma.getPosX()
							&& ((Tanque_E1) ta).getPosX() <= ma.getPosX() + 30) {
						if (((Tanque_E1) ta).getPosY() + 30 >= ma.getPosY()
								&& ((Tanque_E1) ta).getPosY() <= ma.getPosY() + 30) {
							((Tanque_E1) ta).choco1("IZQUIERDA", ma.getPosX() + 31, ma.getPosY());
							choco = true;
						}
					}
				}
			}
		}

		return choco;
	}

	public boolean izquierdaEspecial() {
		boolean choco = false;
		if (ta instanceof Tanque_E2
				&& ((Tanque_E2) ta).getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_IZQUIERDA)) {
			for (int i = 0; i < escenario.getMuros().size(); i++) {
				if (escenario.getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) escenario.getMuros().get(i);
					if (((Tanque_E2) ta).getPosX() + 30 >= ma.getPosx()
							&& ((Tanque_E2) ta).getPosX() <= ma.getPosx() + 30) {
						if (((Tanque_E2) ta).getPosY() + 30 >= ma.getPosy()
								&& ((Tanque_E2) ta).getPosY() <= ma.getPosy() + 30) {
							((Tanque_E2) ta).choco1("IZQUIERDA", ma.getPosx() + 31, ma.getPosy());
							choco = true;
						}
					}
				}
			}
		}
		return choco;
	}

	public boolean arriba() {
		boolean choco = false;
		if (ta instanceof Tanque_E1 && ta.getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_ARRIBA)) {
			for (int i = 0; i < escenario.getMuros().size(); i++) {
				if (escenario.getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) escenario.getMuros().get(i);
					if (((Tanque_E1) ta).getPosX() >= ma.getPosx() && ((Tanque_E1) ta).getPosX() <= ma.getPosx() + 30) {
						if (((Tanque_E1) ta).getPosY() >= ma.getPosy()
								&& ((Tanque_E1) ta).getPosY() <= ma.getPosy() + 30) {
							((Tanque_E1) ta).choco1("ARRIBA", ma.getPosx() - 5, ma.getPosy() + 30);
							choco = true;
						}
					}

				} else if (escenario.getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) escenario.getMuros().get(i);
					if (((Tanque_E1) ta).getPosX() + 30 >= ma.getPosX()
							&& ((Tanque_E1) ta).getPosX() <= ma.getPosX() + 30) {
						if (((Tanque_E1) ta).getPosY() + 30 >= ma.getPosY()
								&& ((Tanque_E1) ta).getPosY() <= ma.getPosY() + 30) {
							((Tanque_E1) ta).choco1("ABAJO", ma.getPosX() - 5, ma.getPosY() + 31);
							choco = true;
						}
					}
				}
			}
		}
		return choco;
	}

	public boolean arribaEspecial() {
		boolean choco = false;
		if (ta instanceof Tanque_E2 && ((Tanque_E2) ta).getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_ARRIBA)) {
			for (int i = 0; i < escenario.getMuros().size(); i++) {
				if (escenario.getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) escenario.getMuros().get(i);
					if (((Tanque_E2) ta).getPosX() >= ma.getPosx() && ((Tanque_E2) ta).getPosX() <= ma.getPosx() + 30) {
						if (((Tanque_E2) ta).getPosY() >= ma.getPosy()
								&& ((Tanque_E2) ta).getPosY() <= ma.getPosy() + 30) {
							((Tanque_E2) ta).choco1("ARRIBA", ma.getPosx() - 5, ma.getPosy() + 33);
							choco = true;
						}
					}
				} else if (escenario.getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) escenario.getMuros().get(i);
					if (((Tanque_E2) ta).getPosX() + 30 >= ma.getPosX()
							&& ((Tanque_E2) ta).getPosX() <= ma.getPosX() + 30) {
						if (((Tanque_E2) ta).getPosY() + 30 >= ma.getPosY()
								&& ((Tanque_E2) ta).getPosY() <= ma.getPosY() + 30) {
							((Tanque_E2) ta).choco1("ARRIBA", ma.getPosX() - 5, ma.getPosY() + 33);
							choco = true;
						}
					}
				}
			}
		}

		return choco;
	}

	public boolean abajo() {
		boolean choco = false;
		if (ta instanceof Tanque_E1 && ta.getImagen().equals(Tanque_E1.TANQUE_ENEMIGO_ABAJO)) {
			for (int i = 0; i < escenario.getMuros().size(); i++) {
				if (escenario.getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) escenario.getMuros().get(i);
					if (((Tanque_E1) ta).getPosX() >= ma.getPosx() && ((Tanque_E1) ta).getPosX() <= ma.getPosx() + 30) {
						if (((Tanque_E1) ta).getPosY() >= ma.getPosy()
								&& ((Tanque_E1) ta).getPosY() <= ma.getPosy() + 30) {
							((Tanque_E1) ta).choco1("ABAJO", ma.getPosx(), ma.getPosy() - 31);
							choco = true;
						}
					}
				} else if (escenario.getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) escenario.getMuros().get(i);
					if (((Tanque_E1) ta).getPosX() + 30 >= ma.getPosX()
							&& ((Tanque_E1) ta).getPosX() <= ma.getPosX() + 30) {
						if (((Tanque_E1) ta).getPosY() + 30 >= ma.getPosY()
								&& ((Tanque_E1) ta).getPosY() <= ma.getPosY() + 30) {
							((Tanque_E1) ta).choco1("ABAJO", ma.getPosX(), ma.getPosY() - 31);
							choco = true;
						}
					}
				}
			}
		}
		return choco;
	}

	public boolean abajoEspecial() {
		boolean choco = false;
		if (ta instanceof Tanque_E2 && ((Tanque_E2) ta).getImagen().equals(Tanque_E2.TANQUE_ENEMIGO_ESPECIAL_ABAJO)) {
			for (int i = 0; i < escenario.getMuros().size(); i++) {
				if (escenario.getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) escenario.getMuros().get(i);
					if (((Tanque_E2) ta).getPosX() >= ma.getPosx() && ((Tanque_E2) ta).getPosX() <= ma.getPosx() + 30) {
						if (((Tanque_E2) ta).getPosY() >= ma.getPosy()
								&& ((Tanque_E2) ta).getPosY() <= ma.getPosy() + 30) {
							((Tanque_E2) ta).choco1("ABAJO", ma.getPosx() + 31, ma.getPosy() - 31);
							choco = true;
						}
					}
				} else if (escenario.getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) escenario.getMuros().get(i);
					if (((Tanque_E2) ta).getPosX() + 30 >= ma.getPosX()
							&& ((Tanque_E2) ta).getPosX() <= ma.getPosX() + 30) {
						if (((Tanque_E2) ta).getPosY() + 30 >= ma.getPosY()
								&& ((Tanque_E2) ta).getPosY() <= ma.getPosY() + 30) {
							((Tanque_E2) ta).choco1("ABAJO", ma.getPosX() + 31, ma.getPosY() - 31);
							choco = true;
						}
					}
				}
			}
		}
		return choco;
	}
}
