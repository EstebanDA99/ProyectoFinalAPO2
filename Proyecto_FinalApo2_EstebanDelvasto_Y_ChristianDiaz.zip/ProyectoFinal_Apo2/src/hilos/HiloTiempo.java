package hilos;

import application.InterfazController;
import application.PanelDatos;

public class HiloTiempo extends Thread {
	public static final long CONVERSION_SEGUNDO = 1000;
	public static final long CONVERSION_MINUTO = 60000;

	private int minutoActual;
	private int segundoActual;
	private PanelDatos escenario;
	private InterfazController princi;

	public HiloTiempo(PanelDatos escena, InterfazController ventana) {
		princi = ventana;
		escenario = escena;
	}

	public void run() {
		while (princi.obtenerTablero().getTanqueJugador().getVida() == 5) {
			try {
				sleep(CONVERSION_SEGUNDO);
				segundoActual += 1;
				if (segundoActual % 2 == 0) {
					princi.dispararTanque();
				}
				if (segundoActual > 60) {
					minutoActual += 1;
					segundoActual = 0;
				}
				escenario.setTiempo(this.segundoActual, this.minutoActual);

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
