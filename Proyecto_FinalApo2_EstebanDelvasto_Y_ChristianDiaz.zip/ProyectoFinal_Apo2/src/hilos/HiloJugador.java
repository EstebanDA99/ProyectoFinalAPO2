package hilos;

import application.InterfazController;
import mundo.*;

public class HiloJugador extends Thread {
	private InterfazController principal;
	private Tablero juga;
	private boolean detenerse;

	public HiloJugador(InterfazController ventana, Tablero ju) {
		principal = ventana;
		juga = ju;
	}

	public void run() {
		while (juga.getTanqueJugador().getVida() == 5 && juga.getWinCondition().getVida() > 0) {
			detenerse = juga.getTanqueJugador().isDetenerse();
			if (!detenerse) {
				juga.getTanqueJugador().cambiarSentido(principal.obtenerMensaje());
				if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.DERECHA)) {
					derecha();
				}
				if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.IZQUIERDA)) {
					izquierda();
				}
				if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.ARRIBA)) {
					arriba();
					arribaTanque();
				}
				if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.ABAJO)) {
					abajo();
				}
			}
			principal.refrescar();
			try {
				sleep(10);
			} catch (Exception e) {
			}
		}
	}

	public void derecha() {
		if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.DERECHA)) {
			for (int i = 0; i < principal.obtenerTablero().getMuros().size(); i++) {
				if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) principal.obtenerTablero().getMuros().get(i);
					if (juga.getTanqueJugador().getPosX() + juga.getTanqueJugador().getDimension() >= ma.getPosx()
							&& juga.getTanqueJugador().getPosX() <= ma.getPosx() + ma.getAlto()) {
						if (juga.getTanqueJugador().getPosY() + juga.getTanqueJugador().getDimension() >= ma.getPosy()
								&& juga.getTanqueJugador().getPosY() <= ma.getPosy() + ma.getAncho()) {
							juga.getTanqueJugador().choco("DERECHA", ma.getPosx() - 30, ma.getPosy());
						}
					}
				} else if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) principal.obtenerTablero().getMuros().get(i);
					if (juga.getTanqueJugador().getPosX() + juga.getTanqueJugador().getDimension() >= ma.getPosX()
							&& juga.getTanqueJugador().getPosX() <= ma.getPosX() + ma.getAlto()) {
						if (juga.getTanqueJugador().getPosY() + juga.getTanqueJugador().getDimension() >= ma.getPosY()
								&& juga.getTanqueJugador().getPosY() <= ma.getPosY() + ma.getAncho()) {
							juga.getTanqueJugador().choco("DERECHA", ma.getPosX() - 30, ma.getPosY());
						}
					}
				}
			}
		}
	}

	public void izquierda() {
		if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.IZQUIERDA)) {
			for (int i = 0; i < principal.obtenerTablero().getMuros().size(); i++) {
				if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) principal.obtenerTablero().getMuros().get(i);
					if (juga.getTanqueJugador().getPosX() + juga.getTanqueJugador().getDimension() >= ma.getPosx()
							&& juga.getTanqueJugador().getPosX() <= ma.getPosx() + ma.getAlto()) {
						if (juga.getTanqueJugador().getPosY() + juga.getTanqueJugador().getDimension() >= ma.getPosy()
								&& juga.getTanqueJugador().getPosY() <= ma.getPosy() + ma.getAncho()) {
							juga.getTanqueJugador().choco("IZQUIERDA", ma.getPosx() + 31, ma.getPosy());
						}
					}
				} else if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) principal.obtenerTablero().getMuros().get(i);
					if (juga.getTanqueJugador().getPosX() + juga.getTanqueJugador().getDimension() >= ma.getPosX()
							&& juga.getTanqueJugador().getPosX() <= ma.getPosX() + ma.getAlto()) {
						if (juga.getTanqueJugador().getPosY() + juga.getTanqueJugador().getDimension() >= ma.getPosY()
								&& juga.getTanqueJugador().getPosY() <= ma.getPosY() + ma.getAncho()) {
							juga.getTanqueJugador().choco("IZQUIERDA", ma.getPosX() + 31, ma.getPosY());
						}
					}
				}
			}
		}
	}

	public void arriba() {
		if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.ARRIBA)) {
			for (int i = 0; i < principal.obtenerTablero().getMuros().size(); i++) {
				if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) principal.obtenerTablero().getMuros().get(i);
					if (juga.getTanqueJugador().getPosX() >= ma.getPosx()
							&& juga.getTanqueJugador().getPosX() <= ma.getPosx() + ma.getAlto()) {
						if (juga.getTanqueJugador().getPosY() >= ma.getPosy()
								&& juga.getTanqueJugador().getPosY() <= ma.getPosy() + ma.getAncho()) {
							juga.getTanqueJugador().choco("ARRIBA", ma.getPosx(), ma.getPosy() + 31);
						}
					}
				} else if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) principal.obtenerTablero().getMuros().get(i);
					if (juga.getTanqueJugador().getPosX() >= ma.getPosX()
							&& juga.getTanqueJugador().getPosX() <= ma.getPosX() + ma.getAlto()) {
						if (juga.getTanqueJugador().getPosY() >= ma.getPosY()
								&& juga.getTanqueJugador().getPosY() <= ma.getPosY() + ma.getAncho()) {
							juga.getTanqueJugador().choco("ARRIBA", ma.getPosX(), ma.getPosY() + 31);
						}
					}
				}
			}
		}
	}


	public void arribaTanque() {
		if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.ARRIBA))
			for (int i = 0; i < juga.getTanquesEnemigos().size(); i++) {
				if (juga.getTanquesEnemigos().get(i) != null) {
					if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E1) {
						Tanque_E1 ma = (Tanque_E1) principal.obtenerTablero().getTanquesEnemigos().get(i);
						if (juga.getTanqueJugador().getPosX() >= ma.getPosX()
								&& juga.getTanqueJugador().getPosX() <= ma.getPosX() + 30) {
							if (juga.getTanqueJugador().getPosY() >= ma.getPosY()
									&& juga.getTanqueJugador().getPosY() <= ma.getPosY() + 30) {
								juga.getTanqueJugador().choco("ARRIBA", ma.getPosX(), ma.getPosY() + 31);
							}
						}
					} else if (principal.obtenerTablero().getTanquesEnemigos().get(i) instanceof Tanque_E2) {
						Tanque_E2 ma = (Tanque_E2) principal.obtenerTablero().getTanquesEnemigos().get(i);
						if (juga.getTanqueJugador().getPosX() >= ma.getPosX()
								&& juga.getTanqueJugador().getPosX() <= ma.getPosX() + 30) {
							if (juga.getTanqueJugador().getPosY() >= ma.getPosY()
									&& juga.getTanqueJugador().getPosY() <= ma.getPosY() + 30) {
								juga.getTanqueJugador().choco("ARRIBA", ma.getPosX(), ma.getPosY() + 31);
								ma.choco1("ARRIBA", juga.getTanqueJugador().getPosX(),
										juga.getTanqueJugador().getPosY() - 30);
							}
						}
					}
				}
			}
	}

	public void abajo() {
		if (juga.getTanqueJugador().getImagen().equals(TanqueJugador.ABAJO)) {
			for (int i = 0; i < principal.obtenerTablero().getMuros().size(); i++) {
				if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Ladrillo) {
					Muro_Ladrillo ma = (Muro_Ladrillo) principal.obtenerTablero().getMuros().get(i);
					if (juga.getTanqueJugador().getPosX() + 30 >= ma.getPosx()
							&& juga.getTanqueJugador().getPosX() <= ma.getPosx() + ma.getAlto()) {
						if (juga.getTanqueJugador().getPosY() + 30 >= ma.getPosy()
								&& juga.getTanqueJugador().getPosY() <= ma.getPosy() + ma.getAncho()) {
							juga.getTanqueJugador().choco("ABAJO", ma.getPosx(), ma.getPosy() - 31);
						}
					}
				} else if (principal.obtenerTablero().getMuros().get(i) instanceof Muro_Indestructible) {
					Muro_Indestructible ma = (Muro_Indestructible) principal.obtenerTablero().getMuros().get(i);
					if (juga.getTanqueJugador().getPosX() + 30 >= ma.getPosX()
							&& juga.getTanqueJugador().getPosX() <= ma.getPosX() + ma.getAlto()) {
						if (juga.getTanqueJugador().getPosY() + 30 >= ma.getPosY()
								&& juga.getTanqueJugador().getPosY() <= ma.getPosY() + ma.getAncho()) {
							juga.getTanqueJugador().choco("ABAJO", ma.getPosX(), ma.getPosY() - 31);
						}
					}
				}
			}
		}
	}
}