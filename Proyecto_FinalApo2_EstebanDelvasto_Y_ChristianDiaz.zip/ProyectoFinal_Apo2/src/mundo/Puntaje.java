package mundo;

import java.io.Serializable;
import java.util.ArrayList;

public class Puntaje implements Serializable{
	private String nombreJugador;
	private int puntajeJugador;
	private Puntaje anterior;
	private Puntaje siguiente;
	private String tiempo;
	public Puntaje(String nombre, int puntaje, String time) {
		nombreJugador=nombre;
		puntajeJugador=puntaje;
		tiempo=time;
	}
	public Puntaje getAnterior() {
		return anterior;
	}
	public void setAnterior(Puntaje anterior) {
		this.anterior = anterior;
	}
	public Puntaje getSiguiente() {
		return siguiente;
	}
	public void setSiguiente(Puntaje siguiente) {
		this.siguiente = siguiente;
	}
	public String getNombreJugador() {
		return nombreJugador;
	}
	public void setNombreJugador(String nombreJugador) {
		this.nombreJugador = nombreJugador;
	}
	public int getPuntajeJugador() {
		return puntajeJugador;
	}
	public void setPuntajeJugador(int puntajeJugador) {
		this.puntajeJugador = puntajeJugador;
	}
	public boolean comparar(Puntaje p) {
		if (nombreJugador.equals(p.getNombreJugador()) && puntajeJugador==p.getPuntajeJugador()) {
			return true;
		} else {
			return false;
		}
	}
	public String getTiempo() {
		return tiempo;
	}
	public void setTiempo(String tiempo) {
		this.tiempo = tiempo;
	}
}
