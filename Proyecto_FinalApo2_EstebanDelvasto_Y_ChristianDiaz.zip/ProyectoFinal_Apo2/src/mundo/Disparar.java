package mundo;

public interface Disparar {
	public void disparar();

}
