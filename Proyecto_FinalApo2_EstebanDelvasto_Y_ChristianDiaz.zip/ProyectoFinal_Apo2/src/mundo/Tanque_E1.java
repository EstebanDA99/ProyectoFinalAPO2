package mundo;

public class Tanque_E1 extends Tanque implements MoverseTanquesEnemigos {
	public static final String TANQUE_ENEMIGO_ARRIBA = "./data/sprites/TanqueEnemigoArriba.png";
	public static final String TANQUE_ENEMIGO_DERECHA = "./data/sprites/TanqueEnemigoDerecha.png";
	public static final String TANQUE_ENEMIGO_ABAJO = "./data/sprites/TanqueEnemigoAbajo.png";
	public static final String TANQUE_ENEMIGO_IZQUIERDA = "./data/sprites/TanqueEnemigoIzquierda.png";
	private String imagen;
	private int vida;
	private int ataque;
	private int posX;
	private int posY;
	private int avance;
	private boolean estado;
	private boolean detenerse;
	private int seMueve;

	public Tanque_E1(int vi, int pos, int pos2, String va, int ava, boolean esta, int recom) {
		super(pos, pos2, recom);
		imagen = TANQUE_ENEMIGO_ARRIBA;
		vida = vi;
		posX = pos;
		posY = pos2;
		avance = ava;
		estado = esta;
		detenerse = false;
		seMueve = (int) (Math.random() * 3);
		super.setRecompensa(300);
	}

	@Override
	public void moverse(int numeroDireccion) {
		// Abajo
		if (numeroDireccion == 0) {
			setImagen(TANQUE_ENEMIGO_ABAJO);
			posY += avance;
		} // Arriba
		else if (numeroDireccion == 1) {
			setImagen(TANQUE_ENEMIGO_ARRIBA);
			posY -= avance;
		} // Derecha
		else if (numeroDireccion == 2) {
			setImagen(TANQUE_ENEMIGO_DERECHA);
			posX += avance;
		} // Izquierda
		else if (numeroDireccion == 3) {
			setImagen(TANQUE_ENEMIGO_IZQUIERDA);
			posX -= avance;
		}
		if (posX > (660)) {
			posX = 660;
			// posX += 0;
			choco("DERECHA");
		} else if (posX < 0) {
			posX = 0;
			// posX += 0;
			choco("IZQUIERDA");
		} else if (posY >= 640) {
			posY = 638;
			// posY += 0;
			choco("ABAJO");
		} else if (posY < 0) {
			posY = 1;
			// posY += 0;
			choco("ARRIBA");
		}
	}

	public void choco(String coordenada) {
		if (coordenada.equals("DERECHA")) {
			int posibilidad = (int) (Math.random() * 3);
			if (posibilidad == 2) {
				posibilidad = 3;
			}
			seMueve = posibilidad;
		} else if (coordenada.equals("IZQUIERDA")) {
			int posibilidad = (int) (Math.random() * 3);
			if (posibilidad == 3) {
				posibilidad = 2;
			}
			seMueve = posibilidad;
		} else if (coordenada.equals("ABAJO")) {
			int posibilidad = (int) (Math.random() * 3);
			if (posibilidad == 0) {
				posibilidad = 1;
			}
			seMueve = posibilidad;
		} else if (coordenada.equals("ARRIBA")) {
			int posibilidad = (int) (Math.random() * 3);
			if (posibilidad == 1) {
				posibilidad = 0;
			}
			seMueve = posibilidad;
		}
	}

	public void choco1(String posicion, int x, int y) {
		if (posicion.equals("DERECHA")) {
			posX = x;
			posX += 0;
			detenerse = true;
		} else if (posicion.equals("IZQUIERDA")) {
			posX = x;
			posX -= 0;
			detenerse = true;
		} else if (posicion.equals("ARRIBA")) {
			posY = y;
			posY -= 0;
			detenerse = true;
		} else if (posicion.equals("ABAJO")) {
			posY = y;
			posY += 0;
			detenerse = true;
		}
	}

	public void destruirTanque(int i) {
		setVida(vida - i);
		if (vida == 0) {
			setEstado(true);
		}
	}

	public int getSeMueve() {
		return seMueve;
	}

	public void setSeMueve(int seMueve) {
		this.seMueve = seMueve;
	}

	public boolean isDetenerse() {
		return detenerse;
	}

	public void setDetenerse(boolean detenerse) {
		this.detenerse = detenerse;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getAtaque() {
		return ataque;
	}

	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

	public int getAvance() {
		return avance;
	}

	public void setAvance(int avance) {
		this.avance = avance;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}
}
