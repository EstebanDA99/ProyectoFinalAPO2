package mundo;

public class Bala implements Disparar {
	public static final int DANO = 5;
	public static final int DANOJ = 1;
	public static final String BALA_NORMAL = "data/sprites/Bala.png";
	public static final String BALA_DERECHA = "data/sprites/Bala1.png";
	public static final String BALA_ABAJO = "data/sprites/Bala2.png";
	public static final String BALA_IZQUIERDA = "data/sprites/Bala3.png";
	private String imagen;
	private int dano;
	private int danoj;
	private int posx;
	private int posy;
	private int avance;
	private String direccion;
	private boolean estado;
	private boolean tanque;
	public Bala() {
		imagen = BALA_NORMAL;
	}

	public Bala(int posX, int posY, String direcc) {
		posx = posX;
		posy = posY;
		setDireccion(direcc);
		estado = true;
		dano = DANO;
		danoj = DANOJ; 
		if (direccion.equals("AVANZAR")) {
			imagen = Bala.BALA_DERECHA;
		} else if (direccion.equals("RETROCEDER")) {
			imagen = Bala.BALA_IZQUIERDA;
		} else if (direccion.equals("ARRIBA")) {
			imagen = Bala.BALA_NORMAL;
		} else if (direccion.equals("ABAJO")) {
			imagen = Bala.BALA_ABAJO;

		}
		tanque=false;
		avance=1;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public int getDano() {
		return dano;
	}
	public int getDanoj() {
		return danoj;
	}


	public void setDanoj(int danoj) {
		this.danoj = danoj;
	}
	public void setDano(int dano) {
		this.dano = dano;
	}

	public int getPosx() {
		return posx;
	}

	public void setPosx(int posx) {
		this.posx = posx;
	}

	public int getPosy() {
		return posy;
	}

	public void setPosy(int posy) {
		this.posy = posy;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void disparar() {
		if (direccion.equals("AVANZAR")) {
			posx += avance;
		} else if (direccion.equals("RETROCEDER")) {
			posx -= avance;
		} else if (direccion.equals("ARRIBA")) {
			posy -= avance;
		} else if (direccion.equals("ABAJO")) {
			posy += avance;
		}
	}

	public boolean isTanque() {
		return tanque;
	}

	public void setTanque(boolean tanque) {
		this.tanque = tanque;
	}

	public int getAvance() {
		return avance;
	}

	public void setAvance(int avance) {
		this.avance = avance;
	}
	
}
