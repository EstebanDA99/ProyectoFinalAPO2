package mundo;

public class Juego {
	private String nombre;
	private String desarrollado;
	private Tablero tablero;

	public Juego() {
		nombre = "City Tank";
		desarrollado = "";
		tablero = new Tablero();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDesarrollado() {
		return desarrollado;
	}

	public void setDesarrollado(String desarrollado) {
		this.desarrollado = desarrollado;
	}

}
