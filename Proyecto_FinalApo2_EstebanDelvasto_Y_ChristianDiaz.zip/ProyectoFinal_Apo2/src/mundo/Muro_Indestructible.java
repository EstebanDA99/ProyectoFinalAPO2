package mundo;

public class Muro_Indestructible extends Muro {
	private int posX;
	private int posY;
	private int alto;
	private int ancho;
	public Muro_Indestructible(int vid, String ima, boolean destru,int pos,int pos2,int alt, int anch) {
		super(pos, pos2, vid, ima, destru);
		posX=pos;
		posY=pos2;
		super.setImagen("data/sprites/Muro1.png");
		alto=alt;
		ancho=anch;
	}
	public int getAlto() {
		return alto;
	}
	public void setAlto(int alto) {
		this.alto = alto;
	}
	public int getAncho() {
		return ancho;
	}
	public void setAncho(int ancho) {
		this.ancho = ancho;
	}
	public int getPosX() {
		return posX;
	}
	public void setPosX(int posX) {
		this.posX = posX;
	}
	public int getPosY() {
		return posY;
	}
	public void setPosY(int posY) {
		this.posY = posY;
	}

}
