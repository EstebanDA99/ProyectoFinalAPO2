package mundo;

import java.util.ArrayList;

public class TanqueJugador extends Tanque implements Colision {
	public static final String ARRIBA = "data/sprites/TanqueJugador.png";
	public static final String ABAJO = "data/sprites/TanqueJugador2.png";
	public static final String DERECHA = "data/sprites/TanqueJugador1.png";
	public static final String IZQUIERDA = "data/sprites/TanqueJugador3.png";
	private String imagen;
	private int posX;
	private int posY;
	private boolean detenerse;
	private int vida;
	private Tablero table;
	private int dimension;
	public TanqueJugador(int posx, int posy, Tablero t, int dimensio, int recom) {
		super(posx, posy, recom);
		setPosX(posx);
		setPosY(posy);
		imagen = ARRIBA;
		setVida(5);
		setDetenerse(false);
		vida = 5;
		table = t;
		dimension = dimensio;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}
	// Metodos

	public void cambiarSentido(String mensaje) {
		if (mensaje.equals("AVANZAR")) {
			posX += Tanque.MOVIMIENTO_TANQUE_NORMAL;
			// setPosX(posX);
		} else if (mensaje.equals("RETROCEDER")) {
			posX -= Tanque.MOVIMIENTO_TANQUE_NORMAL;
			// setPosX(posX);
		} else if (mensaje.equals("ARRIBA")) {
			posY -= Tanque.MOVIMIENTO_TANQUE_NORMAL;
			// setPosY(posY);
		} else if (mensaje.equals("ABAJO")) {
			posY += Tanque.MOVIMIENTO_TANQUE_NORMAL;
			// setPosY(posY);
		}
		if (posX > (660)) {
			posX = 660;
			posX += 0;
		} else if (posX < 0) {
			posX = 0;
			posX += 0;
		} else if (posY >= 640) {
			posY = 640;
			posY += 0;
		} else if (posY < 0) {
			posY = 0;
			posY += 0;
		}
		detenerse = true;

}

	public boolean isDetenerse() {
		return detenerse;
	}

	public void setDetenerse(boolean detenerse) {
		this.detenerse = detenerse;
	}

	public void DispararBala() {
		super.disparar();
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public Tablero getTable() {
		return table;
	}

	public void setTable(Tablero table) {
		this.table = table;
	}

	public void choco(String posicion,int x, int y) {
		if(posicion.equals("DERECHA")) {
			posX=x;
			posX+=0;
			detenerse=true;
		}else if(posicion.equals("IZQUIERDA")) {
			posX=x;
			posX-=0;
			detenerse=true;
		}else if(posicion.equals("ARRIBA")) {
			posY=y;
			posY-=0;
			detenerse=true;
		}else if(posicion.equals("ABAJO")) {
			posY=y;
			posY+=0;
			detenerse=true;
		}
	}
	public int getDimension() {
		return dimension;
	}
	public void quitarVidaj(int danoj) {
		vida=vida-danoj;
	}
	public void quitarVida(int dano) {
		vida=vida-dano;
	}
	public void setDimension(int dimension) {
		this.dimension = dimension;
	}
}
