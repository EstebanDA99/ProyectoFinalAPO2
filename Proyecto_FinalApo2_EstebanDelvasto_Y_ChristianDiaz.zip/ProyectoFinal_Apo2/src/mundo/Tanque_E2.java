package mundo;

public class Tanque_E2 extends Tanque implements MoverseTanquesEnemigos{
	public static final String TANQUE_ENEMIGO_ESPECIAL_ARRIBA="./data/sprites/TanqueEspecial.png";
	public static final String TANQUE_ENEMIGO_ESPECIAL_DERECHA="./data/sprites/TanqueEspecialDerecha.png";
	public static final String TANQUE_ENEMIGO_ESPECIAL_ABAJO="./data/sprites/TanqueEspecialAbajo.png";
	public static final String TANQUE_ENEMIGO_ESPECIAL_IZQUIERDA="./data/sprites/TanqueEspecialIzquierda.png";
	private int vida;
	private String imagen;
	private int avance;
	private int posX;
	private int posY;
	private boolean destruido;
	private boolean detenerse;
	private int seMueve;
	public Tanque_E2(int vi, String ima, int ava, int pos,int pos2, boolean estado, int recom) {
		super(pos, pos2, recom);
		vida=vi;
		imagen=ima;
		avance=ava;
		posX=pos;
		posY=pos2;
		destruido=estado;
		detenerse=false;
		seMueve=(int)(Math.random()*3);
	}
	public int getSeMueve() {
		return seMueve;
	}
	public void setSeMueve(int seMueve) {
		this.seMueve = seMueve;
	}
	public boolean isDetenerse() {
		return detenerse;
	}
	public void setDetenerse(boolean detenerse) {
		this.detenerse = detenerse;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public String getImagen() {
		return imagen;
	}
	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	public int getAvance() {
		return avance;
	}
	public void setAvance(int avance) {
		this.avance = avance;
	}
	public int getPosX() {
		return posX;
	}
	public void setPosX(int posX) {
		this.posX = posX;
	}
	public int getPosY() {
		return posY;
	}
	public void setPosY(int posY) {
		this.posY = posY;
	}
	@Override
	public void moverse(int numeroDireccion) {
			//Abajo
			if(numeroDireccion==0) {
				setImagen(TANQUE_ENEMIGO_ESPECIAL_ABAJO);
				posY+=avance;
			}//Arriba
			else if(numeroDireccion==1) {
				setImagen(TANQUE_ENEMIGO_ESPECIAL_ARRIBA);
				posY-=avance;
			}//Derecha
			else if(numeroDireccion==2) {
				setImagen(TANQUE_ENEMIGO_ESPECIAL_DERECHA);
				posX+=avance;
			}//Izquierda
			else if(numeroDireccion==3) {
				setImagen(TANQUE_ENEMIGO_ESPECIAL_IZQUIERDA);
				posX-=avance;
			}
			if (posX > (660)) {
				posX = 660;
//				posX += 0;
				choco("DERECHA");
			} else if (posX < 0) {
				posX = 0;
//				posX += 0;
				choco("IZQUIERDA");
			} else if (posY >= 640) {
				posY = 640;
//				posY += 0;
				choco("ABAJO");
			} else if (posY < 0) {
				posY = 0;
//				posY += 0;
				choco("ARRIBA");
			}
	}
	public void choco(String coordenada) {
		if(coordenada.equals("DERECHA")) {
			int posibilidad=(int)(Math.random()*3);
			if(posibilidad==2) {
				posibilidad=3;
			}
			seMueve=posibilidad;
		}else if(coordenada.equals("IZQUIERDA")) {
			int posibilidad=(int)(Math.random()*3);
			if(posibilidad==3) {
				posibilidad=2;
			}
			seMueve=posibilidad;
		}else if(coordenada.equals("ABAJO")) {
			int posibilidad=(int)(Math.random()*3);
			if(posibilidad==0) {
			}
			seMueve=posibilidad;
		}else if(coordenada.equals("ARRIBA")) {
			int posibilidad=(int)(Math.random()*3);
			if(posibilidad==1) {
				posibilidad=0;
			}
			seMueve=posibilidad;
		}
	}
	public void choco1(String posicion,int x, int y) {
		if(posicion.equals("DERECHA")) {
			posX=x;
			posX+=0;
			detenerse=true;
		}else if(posicion.equals("IZQUIERDA")) {
			posX=x;
			posX-=0;
			detenerse=true;
		}else if(posicion.equals("ARRIBA")) {
			posY=y;
			posY-=0;
			detenerse=true;
		}else if(posicion.equals("ABAJO")) {
			posY=y;
			posY+=0;
			detenerse=true;
		}
	}
	public void destruirTanque(int i) {
		setVida(vida-i);
		if(vida==0) {
			setDestruido(true);
		}
	}
	public boolean isDestruido() {
		return destruido;
	}
	public void setDestruido(boolean destruido) {
		this.destruido = destruido;
	}
}
