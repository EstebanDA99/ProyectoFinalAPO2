package mundo;

public class Aguila_Defender implements Destruido {
	public final static int VIDA = 1;
	public static final String IMAGEN = "data/sprites/AguilaDefender.png";
	private int vida;
	private int posX;
	private int posY;
	private String imagen;

	public Aguila_Defender(int posicionx, int posiciony) {
		vida = VIDA;
		posX = posicionx;
		posY = posiciony;
		imagen = IMAGEN;
	}

	public int getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	@Override
	public boolean destruido() {
		if(vida==0) {
			return true;
		}else {
			return false;
		}
	}
}
