package mundo;

public interface Destruido {
	 boolean destruido();

}
