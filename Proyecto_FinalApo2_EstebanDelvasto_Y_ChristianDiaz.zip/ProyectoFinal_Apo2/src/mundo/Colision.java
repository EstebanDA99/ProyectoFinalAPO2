package mundo;

public interface Colision {

	public void choco(String posicion,int x,int y);
}
